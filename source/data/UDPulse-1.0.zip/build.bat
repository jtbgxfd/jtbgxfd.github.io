@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"

where g++ >nul 2>nul
if errorlevel 1 (
  echo [错误] 没有找到 g++，请安装 MinGW-w64 并加入 PATH
  pause
  exit /b 1
)

echo 正在编译 UDPulse.exe ...
g++ -std=c++17 -O2 -DUNICODE -D_UNICODE -mwindows -pthread ^
    src\main.cpp src\ui.cpp src\chat_server.cpp src\chat_client.cpp ^
    -o UDPulse.exe ^
    -lgdiplus -lws2_32 -limm32 -lgdi32 -luser32 -lshell32 ^
    -static -static-libgcc -static-libstdc++

if errorlevel 1 (
  echo.
  echo [失败] 编译出错，请查看上面的信息
  pause
  exit /b 1
)

echo.
echo 构建完成：UDPulse.exe（单文件，无需任何 DLL）
pause
exit /b 0
