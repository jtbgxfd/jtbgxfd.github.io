// ============================================================================
//  UDPulse · 程序入口
//  默认：启动本地 UDP 服务器（端口占用则自动跳过）+ 打开聊天界面
//  --connect HOST  只做客户端，连接指定服务器
//  --server        纯控制台服务器模式（无界面）
// ============================================================================
#include "chat_client.h"
#include "chat_server.h"
#include "common.h"
#include "ui.h"

#include <windows.h>
#include <objidl.h>
#include <gdiplus.h>

#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <string>
#include <vector>

namespace {

void show_usage() {
    MessageBoxW(nullptr,
                L"UDPulse · C++ UDP 聊天室\n\n"
                L"双击直接使用：本机会自动开启聊天服务并进入界面。\n\n"
                L"命令行参数：\n"
                L"  --name 昵称        预填昵称\n"
                L"  --port 9000        指定 UDP 端口\n"
                L"  --connect IP       连接指定服务器（不再本机开服）\n"
                L"  --server           仅运行控制台服务器\n"
                L"  --help             显示本帮助",
                L"UDPulse", MB_OK | MB_ICONINFORMATION);
}

int run_server_console(uint16_t port) {
    if (!AllocConsole()) return 1;
    FILE* dummy = nullptr;
    freopen_s(&dummy, "CONOUT$", "w", stdout);
    freopen_s(&dummy, "CONIN$", "r", stdin);
    SetConsoleTitleW(L"UDPulse Server");

    chat::setup_console();

    chat::ChatServer server({port});
    server.set_logger([](const std::string& line) { chat::log_line("SRV", line); });

    std::cout << "\n  UDPulse 服务器模式\n";
    std::cout << "  监听 UDP " << port << "，输入文字以管理员身份广播，输入 quit 退出\n\n";

    if (!server.start()) {
        std::cout << "  启动失败：端口 " << port << " 可能被占用\n";
        std::cout << "  按回车退出…\n";
        std::cin.get();
        return 1;
    }

    std::string line;
    while (std::getline(std::cin, line)) {
        if (line == "quit" || line == "exit") break;
        if (!line.empty()) server.broadcast_notice(line);
    }
    server.stop();
    return 0;
}

}  // namespace

int WINAPI WinMain(HINSTANCE inst, HINSTANCE, LPSTR, int nCmdShow) {
    chat::setup_console();

    Gdiplus::GdiplusStartupInput gdi_input;
    ULONG_PTR gdi_token = 0;
    if (Gdiplus::GdiplusStartup(&gdi_token, &gdi_input, nullptr) != Gdiplus::Ok) {
        MessageBoxW(nullptr, L"初始化图形库失败", L"UDPulse", MB_ICONERROR);
        return 1;
    }

    chat::SocketRuntime socket_runtime;

    std::string host = "127.0.0.1";
    std::string name;
    uint16_t port = 9000;
    bool server_only = false;
    bool connect_remote = false;

    const std::vector<std::string> args = chat::utf8_command_line_args();
    for (size_t i = 1; i < args.size(); ++i) {
        const std::string& arg = args[i];
        if (arg == "--connect" && i + 1 < args.size()) {
            host = args[++i];
            connect_remote = true;
        } else if (arg == "--port" && i + 1 < args.size()) {
            port = static_cast<uint16_t>(std::atoi(args[++i].c_str()));
        } else if (arg == "--name" && i + 1 < args.size()) {
            name = args[++i];
        } else if (arg == "--server") {
            server_only = true;
        } else if (arg == "--help" || arg == "-h") {
            show_usage();
            Gdiplus::GdiplusShutdown(gdi_token);
            return 0;
        }
    }

    if (server_only) {
        const int code = run_server_console(port);
        Gdiplus::GdiplusShutdown(gdi_token);
        return code;
    }

    chat::ChatServer server({port});
    bool hosted = false;
    if (!connect_remote) {
        hosted = server.start();
    }

    chat::ChatClient client;
    if (!client.connect_to(host, port)) {
        MessageBoxW(nullptr, L"无法创建 UDP 连接，请检查网络配置", L"UDPulse", MB_ICONERROR);
        server.stop();
        Gdiplus::GdiplusShutdown(gdi_token);
        return 1;
    }

    chat::UiOptions opt;
    opt.host = host;
    opt.port = port;
    opt.hosted = hosted;
    opt.name = name;

    const int code = chat::run_ui(inst, nCmdShow, client, hosted ? &server : nullptr, opt);

    client.close();
    server.stop();
    Gdiplus::GdiplusShutdown(gdi_token);
    return code;
}
