#pragma once
// ============================================================================
//  UI · Win32 + GDI+ 自绘聊天界面（纯 C++，无 HTML/JS）
// ============================================================================
#include "chat_client.h"
#include "chat_server.h"
#include "common.h"

#include <string>

namespace chat {

struct UiOptions {
    std::string host;
    uint16_t port = 9000;
    bool hosted = false;  // 本进程是否托管了服务器
    std::string name;     // 预填昵称
};

// 阻塞运行消息循环，返回进程退出码
int run_ui(HINSTANCE inst, int nCmdShow, ChatClient& client, ChatServer* server, const UiOptions& opt);

}  // namespace chat
