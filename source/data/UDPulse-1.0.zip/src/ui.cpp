// ============================================================================
//  UDPulse · Win32 + GDI+ 自绘聊天界面
//  全部界面元素由 GDI+ 绘制，输入框使用系统 EDIT 子控件以完整支持中文输入法
// ============================================================================
#include "ui.h"

#include <windows.h>
#include <windowsx.h>
#include <objidl.h>
#include <gdiplus.h>
#include <imm.h>

#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <cwchar>
#include <memory>
#include <unordered_set>
#include <utility>
#include <vector>

namespace chat {
namespace {

using namespace Gdiplus;

constexpr int kMaxMessages = 300;
constexpr int kEditId = 1001;
constexpr UINT kPingTimer = 1;
constexpr UINT kToastTimer = 2;
constexpr UINT kTypingTimer = 3;
constexpr UINT kMsgTimer = 4;
constexpr UINT WM_APP_NET = WM_APP + 1;
constexpr UINT WM_APP_SEND = WM_APP + 2;

// ------------------------------------------------------------------ 调色板
struct Palette {
    Color bg_top, bg_bottom, glow;
    Color panel, panel_border;
    Color text, text_dim, text_faint;
    Color bubble_in, bubble_border;
    Color accent_a, accent_b;
    Color sys_bg, sys_border;
    Color input_bg, input_border;
    Color scroll_thumb;
    Color hover;
    Color success, warn, danger;
};

Palette make_dark() {
    Palette p{};
    p.bg_top = Color(255, 13, 18, 30);
    p.bg_bottom = Color(255, 6, 9, 15);
    p.glow = Color(58, 99, 102, 241);
    p.panel = Color(240, 17, 23, 35);
    p.panel_border = Color(22, 255, 255, 255);
    p.text = Color(255, 233, 237, 245);
    p.text_dim = Color(255, 152, 162, 182);
    p.text_faint = Color(255, 98, 108, 128);
    p.bubble_in = Color(255, 25, 32, 48);
    p.bubble_border = Color(18, 255, 255, 255);
    p.accent_a = Color(255, 99, 102, 241);
    p.accent_b = Color(255, 139, 92, 246);
    p.sys_bg = Color(255, 22, 28, 42);
    p.sys_border = Color(16, 255, 255, 255);
    p.input_bg = Color(255, 21, 27, 40);
    p.input_border = Color(24, 255, 255, 255);
    p.scroll_thumb = Color(130, 255, 255, 255);
    p.hover = Color(12, 255, 255, 255);
    p.success = Color(255, 52, 211, 153);
    p.warn = Color(255, 251, 191, 36);
    p.danger = Color(255, 248, 113, 113);
    return p;
}

Palette make_light() {
    Palette p{};
    p.bg_top = Color(255, 245, 248, 254);
    p.bg_bottom = Color(255, 226, 233, 246);
    p.glow = Color(46, 99, 102, 241);
    p.panel = Color(244, 255, 255, 255);
    p.panel_border = Color(22, 15, 23, 42);
    p.text = Color(255, 16, 24, 40);
    p.text_dim = Color(255, 84, 94, 114);
    p.text_faint = Color(255, 124, 135, 155);
    p.bubble_in = Color(255, 238, 242, 249);
    p.bubble_border = Color(16, 15, 23, 42);
    p.accent_a = Color(255, 99, 102, 241);
    p.accent_b = Color(255, 139, 92, 246);
    p.sys_bg = Color(255, 235, 240, 248);
    p.sys_border = Color(14, 15, 23, 42);
    p.input_bg = Color(255, 242, 246, 252);
    p.input_border = Color(28, 15, 23, 42);
    p.scroll_thumb = Color(110, 15, 23, 42);
    p.hover = Color(10, 15, 23, 42);
    p.success = Color(255, 16, 185, 129);
    p.warn = Color(255, 217, 119, 6);
    p.danger = Color(255, 220, 38, 38);
    return p;
}

// ------------------------------------------------------------------ 几何工具
void MakeRoundRect(const RectF& r, float radius, GraphicsPath& p) {
    p.Reset();
    if (radius <= 0.5f) {
        p.AddRectangle(r);
        return;
    }
    const float d = radius * 2;
    p.AddArc(r.X, r.Y, d, d, 180, 90);
    p.AddArc(r.GetRight() - d, r.Y, d, d, 270, 90);
    p.AddArc(r.GetRight() - d, r.GetBottom() - d, d, d, 0, 90);
    p.AddArc(r.X, r.GetBottom() - d, d, d, 90, 90);
    p.CloseFigure();
}

// 气泡：靠近说话者的一角用小圆角
void MakeBubble(const RectF& r, float radius, float tail, bool right, GraphicsPath& p) {
    p.Reset();
    const float d = radius * 2;
    const float td = tail * 2;
    if (r.Width <= d * 1.2f || r.Height <= d * 1.2f) {
        p.AddRectangle(r);
        return;
    }
    p.AddArc(r.X, r.Y, d, d, 180, 90);
    p.AddArc(r.GetRight() - d, r.Y, d, d, 270, 90);
    if (right) p.AddArc(r.GetRight() - td, r.GetBottom() - td, td, td, 0, 90);
    else p.AddArc(r.GetRight() - d, r.GetBottom() - d, d, d, 0, 90);
    if (right) p.AddArc(r.X, r.GetBottom() - d, d, d, 90, 90);
    else p.AddArc(r.X, r.GetBottom() - td, td, td, 90, 90);
    p.CloseFigure();
}

std::wstring first_char_w(const std::string& s) {
    if (s.empty()) return L"?";
    size_t len = 1;
    const unsigned char c = static_cast<unsigned char>(s[0]);
    if ((c & 0xE0) == 0xC0) len = 2;
    else if ((c & 0xF0) == 0xE0) len = 3;
    else if ((c & 0xF8) == 0xF0) len = 4;
    std::wstring w = utf8_to_wide(s.substr(0, std::min(len, s.size())));
    if (w.empty()) return L"?";
    w = w.substr(0, 1);
    if (w[0] >= L'a' && w[0] <= L'z') w[0] = static_cast<wchar_t>(w[0] - L'a' + L'A');
    return w;
}

std::pair<Color, Color> gradient_of(const std::string& name) {
    static const Color kPairs[8][2] = {
        {Color(255, 99, 102, 241), Color(255, 139, 92, 246)},
        {Color(255, 6, 182, 212), Color(255, 59, 130, 246)},
        {Color(255, 245, 158, 11), Color(255, 239, 68, 68)},
        {Color(255, 16, 185, 129), Color(255, 6, 182, 212)},
        {Color(255, 236, 72, 153), Color(255, 139, 92, 246)},
        {Color(255, 249, 115, 22), Color(255, 244, 63, 94)},
        {Color(255, 20, 184, 166), Color(255, 34, 197, 94)},
        {Color(255, 168, 85, 247), Color(255, 99, 102, 241)},
    };
    size_t hash = 0;
    for (unsigned char c : name) hash = hash * 31 + c;
    return {kPairs[hash % 8][0], kPairs[hash % 8][1]};
}

std::wstring format_time_w(int64_t ms) {
    const std::time_t secs = static_cast<std::time_t>(ms / 1000);
    std::tm tmv{};
#ifdef _WIN32
    localtime_s(&tmv, &secs);
#else
    localtime_r(&secs, &tmv);
#endif
    wchar_t buf[8];
    std::swprintf(buf, 8, L"%02d:%02d", tmv.tm_hour, tmv.tm_min);
    return std::wstring(buf);
}

std::string trim_utf8(const std::string& s) {
    size_t b = 0, e = s.size();
    while (b < e && (s[b] == ' ' || s[b] == '\t' || s[b] == '\r' || s[b] == '\n')) ++b;
    while (e > b && (s[e - 1] == ' ' || s[e - 1] == '\t' || s[e - 1] == '\r' || s[e - 1] == '\n')) --e;
    return s.substr(b, e - b);
}

bool ime_composing(HWND hwnd) {
    HIMC imc = ImmGetContext(hwnd);
    if (!imc) return false;
    const LONG len = ImmGetCompositionStringW(imc, GCS_COMPSTR, nullptr, 0);
    ImmReleaseContext(hwnd, imc);
    return len > 0;
}

// ------------------------------------------------------------------ 消息
struct UiMessage {
    std::string id, from, text, to, kind;
    std::wstring wfrom, wtext, wtime;
    int64_t ts = 0;
    bool mine = false;
    bool system = false;
    bool history = false;
    bool grouped = false;
    float top = 0;
    float height = 0;
    float bubble_w = 0;
    float bubble_h = 0;
    float text_w = 0;
    float text_h = 0;
    float text_layout_w = 0;
    float meta_h = 0;
    bool measured = false;
    float measured_w = 0;
};

class ChatApp;
ChatApp* g_app = nullptr;

// ============================================================================
//  ChatApp
// ============================================================================
class ChatApp {
public:
    ChatApp(HINSTANCE inst, ChatClient& client, ChatServer* server, const UiOptions& opt)
        : inst_(inst), client_(client), server_(server), opt_(opt) {
        HDC screen = GetDC(nullptr);
        dpi_ = GetDeviceCaps(screen, LOGPIXELSX);
        ReleaseDC(nullptr, screen);
        scale_ = dpi_ / 96.0f;

        pal_ = make_dark();

        font_body_ = make_font(14.5f, FontStyleRegular);
        font_small_ = make_font(11.5f, FontStyleRegular);
        font_name_ = make_font(12.0f, FontStyleBold);
        font_title_ = make_font(15.5f, FontStyleBold);
        font_brand_ = make_font(15.0f, FontStyleBold);
        font_member_ = make_font(13.5f, FontStyleRegular);
        font_avatar_ = make_font(13.0f, FontStyleBold);
        font_hint_ = make_font(11.0f, FontStyleRegular);
        font_hero_ = make_font(26.0f, FontStyleBold);

        measure_bmp_ = new Bitmap(1, 1, PixelFormat32bppARGB);
        measure_g_ = new Graphics(measure_bmp_);

        me_ = opt.name.empty() ? default_name() : opt.name;
        composer_h_ = S(86);
        g_app = this;
    }

    ~ChatApp() {
        g_app = nullptr;
        if (edit_brush_) DeleteObject(edit_brush_);
        if (edit_font_) DeleteObject(edit_font_);
        delete font_body_;
        delete font_small_;
        delete font_name_;
        delete font_title_;
        delete font_brand_;
        delete font_member_;
        delete font_avatar_;
        delete font_hint_;
        delete font_hero_;
        delete measure_g_;
        delete measure_bmp_;
    }

    int run(int nCmdShow) {
        WNDCLASSEXW wc{};
        wc.cbSize = sizeof(wc);
        wc.style = CS_HREDRAW | CS_VREDRAW | CS_DBLCLKS;
        wc.lpfnWndProc = WndProc;
        wc.hInstance = inst_;
        wc.hCursor = LoadCursorW(nullptr, IDC_ARROW);
        wc.hbrBackground = nullptr;
        wc.lpszClassName = L"UDPulseWindow";
        wc.hIcon = LoadIconW(nullptr, IDI_APPLICATION);
        wc.hIconSm = wc.hIcon;
        RegisterClassExW(&wc);

        hwnd_ = CreateWindowExW(0, L"UDPulseWindow", L"UDPulse · C++ UDP 聊天室",
                                WS_OVERLAPPEDWINDOW | WS_CLIPCHILDREN,
                                CW_USEDEFAULT, CW_USEDEFAULT, S(1120), S(744),
                                nullptr, nullptr, inst_, this);
        if (!hwnd_) return 1;

        RECT rc;
        GetWindowRect(hwnd_, &rc);
        const int sw = GetSystemMetrics(SM_CXSCREEN);
        const int sh = GetSystemMetrics(SM_CYSCREEN);
        SetWindowPos(hwnd_, nullptr,
                     (sw - (rc.right - rc.left)) / 2,
                     (sh - (rc.bottom - rc.top)) / 2,
                     0, 0, SWP_NOSIZE | SWP_NOZORDER);

        ShowWindow(hwnd_, nCmdShow);
        UpdateWindow(hwnd_);
        apply_titlebar();

        client_.set_handler([this](const std::string& raw) {
            auto* copy = new std::string(raw);
            if (!PostMessageW(hwnd_, WM_APP_NET, 0, reinterpret_cast<LPARAM>(copy))) delete copy;
        });

        SetTimer(hwnd_, kPingTimer, 15000, nullptr);

        MSG msg;
        while (GetMessageW(&msg, nullptr, 0, 0) > 0) {
            TranslateMessage(&msg);
            DispatchMessageW(&msg);
        }
        return 0;
    }

private:
    // ---------------------------------------------------------------- 缩放
    float S(float v) const { return std::round(v * scale_); }
    int SI(float v) const { return static_cast<int>(std::round(v * scale_)); }

    Font* make_font(float px, int style) {
        auto* f = new Font(L"Microsoft YaHei UI", px * scale_, style, UnitPixel);
        if (f->GetLastStatus() != Ok) {
            delete f;
            f = new Font(L"Segoe UI", px * scale_, style, UnitPixel);
        }
        return f;
    }

    static std::string default_name() {
        static const char* kPool[] = {"Nova", "Echo", "Lumen", "Kite", "Orbit", "Pixel"};
        const int idx = static_cast<int>((now_ms() / 1000) % 6);
        return std::string(kPool[idx]) + std::to_string(now_ms() % 100);
    }

    // ---------------------------------------------------------------- 窗口过程
    static LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
        ChatApp* self = reinterpret_cast<ChatApp*>(GetWindowLongPtrW(hwnd, GWLP_USERDATA));
        if (msg == WM_NCCREATE) {
            auto* cs = reinterpret_cast<CREATESTRUCTW*>(lp);
            self = reinterpret_cast<ChatApp*>(cs->lpCreateParams);
            SetWindowLongPtrW(hwnd, GWLP_USERDATA, reinterpret_cast<LONG_PTR>(self));
            self->hwnd_ = hwnd;
        }
        if (!self) return DefWindowProcW(hwnd, msg, wp, lp);
        return self->handle(msg, wp, lp);
    }

    static LRESULT CALLBACK EditProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
        ChatApp* self = g_app;
        if (!self) return DefWindowProcW(hwnd, msg, wp, lp);

        if (msg == WM_KEYDOWN && wp == VK_RETURN) {
            const bool shift = (GetKeyState(VK_SHIFT) & 0x8000) != 0;
            if (!shift && !ime_composing(hwnd)) {
                PostMessageW(self->hwnd_, WM_APP_SEND, 0, 0);
                return 0;
            }
        }
        if (msg == WM_CHAR && wp == VK_RETURN) {
            const bool shift = (GetKeyState(VK_SHIFT) & 0x8000) != 0;
            if (!shift) return 0;
        }
        if (msg == WM_KEYDOWN && wp == VK_ESCAPE) {
            if (!self->peer_.empty()) {
                self->peer_.clear();
                self->layout();
                self->invalidate();
                return 0;
            }
        }
        return CallWindowProcW(self->old_edit_proc_, hwnd, msg, wp, lp);
    }

    void invalidate() { InvalidateRect(hwnd_, nullptr, FALSE); }

    // 让系统标题栏跟随界面主题（Win10 2004+ 属性 20，旧版 19）
    void apply_titlebar() {
        HMODULE dwm = LoadLibraryW(L"dwmapi.dll");
        if (!dwm) return;
        using Fn = HRESULT(WINAPI*)(HWND, DWORD, LPCVOID, DWORD);
        auto fn = reinterpret_cast<Fn>(GetProcAddress(dwm, "DwmSetWindowAttribute"));
        if (fn) {
            BOOL dark = dark_ ? TRUE : FALSE;
            if (FAILED(fn(hwnd_, 20, &dark, sizeof(dark)))) {
                fn(hwnd_, 19, &dark, sizeof(dark));
            }
        }
        FreeLibrary(dwm);
    }

    LRESULT handle(UINT msg, WPARAM wp, LPARAM lp) {
        switch (msg) {
            case WM_CREATE:
                create_edit();
                layout();
                return 0;

            case WM_SIZE:
                layout();
                invalidate();
                return 0;

            case WM_GETMINMAXINFO: {
                auto* mmi = reinterpret_cast<MINMAXINFO*>(lp);
                mmi->ptMinTrackSize.x = S(900);
                mmi->ptMinTrackSize.y = S(620);
                return 0;
            }

            case WM_ERASEBKGND:
                return 1;

            case WM_PAINT:
                paint();
                return 0;

            case WM_PRINTCLIENT: {
                // 供 PrintWindow / 截图工具使用，直接渲染到外部 DC
                HDC dc = reinterpret_cast<HDC>(wp);
                Graphics g(dc);
                g.SetSmoothingMode(SmoothingModeAntiAlias);
                g.SetTextRenderingHint(TextRenderingHintAntiAliasGridFit);
                g.SetPixelOffsetMode(PixelOffsetModeHalf);
                draw_background(g);
                if (joined_) {
                    draw_sidebar(g);
                    draw_chat(g);
                } else {
                    draw_login(g);
                }
                draw_toast(g);
                return 0;
            }

            case WM_MOUSEWHEEL: {
                if (!joined_) return 0;
                const int delta = GET_WHEEL_DELTA_WPARAM(wp);
                scroll_y_ -= delta / 120.0f * S(64);
                clamp_scroll();
                invalidate();
                return 0;
            }

            case WM_MOUSEMOVE: {
                const float x = static_cast<float>(GET_X_LPARAM(lp));
                const float y = static_cast<float>(GET_Y_LPARAM(lp));
                update_hover(x, y);
                return 0;
            }

            case WM_LBUTTONDOWN: {
                const float x = static_cast<float>(GET_X_LPARAM(lp));
                const float y = static_cast<float>(GET_Y_LPARAM(lp));
                on_click(x, y);
                return 0;
            }

            case WM_COMMAND:
                if (LOWORD(wp) == kEditId && HIWORD(wp) == EN_CHANGE && joined_) {
                    update_composer_height();
                }
                return 0;

            case WM_CTLCOLOREDIT: {
                HDC dc = reinterpret_cast<HDC>(wp);
                SetTextColor(dc, RGB(pal_.text.GetR(), pal_.text.GetG(), pal_.text.GetB()));
                SetBkColor(dc, RGB(pal_.input_bg.GetR(), pal_.input_bg.GetG(), pal_.input_bg.GetB()));
                return reinterpret_cast<LRESULT>(edit_brush_);
            }

            case WM_TIMER:
                if (wp == kPingTimer) {
                    if (client_.connected()) {
                        ping_sent_ = now_ms();
                        client_.send_json("{\"type\":\"ping\"}");
                    }
                } else if (wp == kToastTimer) {
                    KillTimer(hwnd_, kToastTimer);
                    toast_.clear();
                    invalidate();
                } else if (wp == kTypingTimer) {
                    KillTimer(hwnd_, kTypingTimer);
                    typing_text_.clear();
                    invalidate();
                }
                return 0;

            case WM_APP_SEND:
                submit_input();
                return 0;

            case WM_APP_NET: {
                std::unique_ptr<std::string> raw(reinterpret_cast<std::string*>(lp));
                if (raw) handle_network(*raw);
                return 0;
            }

            case WM_DESTROY:
                if (client_.connected()) client_.send_json("{\"type\":\"leave\"}");
                KillTimer(hwnd_, kPingTimer);
                PostQuitMessage(0);
                return 0;

            default:
                return DefWindowProcW(hwnd_, msg, wp, lp);
        }
    }

    // ---------------------------------------------------------------- 控件
    void create_edit() {
        edit_ = CreateWindowExW(0, L"EDIT", L"",
                                WS_CHILD | WS_VISIBLE | ES_MULTILINE | ES_AUTOVSCROLL | WS_CLIPSIBLINGS,
                                0, 0, 10, 10, hwnd_, reinterpret_cast<HMENU>(kEditId), inst_, nullptr);
        if (!edit_) return;

        edit_font_ = CreateFontW(-SI(14.5f), 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE,
                                 DEFAULT_CHARSET, OUT_TT_PRECIS, CLIP_DEFAULT_PRECIS,
                                 CLEARTYPE_QUALITY, DEFAULT_PITCH, L"Microsoft YaHei UI");
        if (!edit_font_) edit_font_ = static_cast<HFONT>(GetStockObject(DEFAULT_GUI_FONT));
        SendMessageW(edit_, WM_SETFONT, reinterpret_cast<WPARAM>(edit_font_), TRUE);
        SendMessageW(edit_, EM_SETLIMITTEXT, 1200, 0);
        SendMessageW(edit_, EM_SETMARGINS, EC_LEFTMARGIN | EC_RIGHTMARGIN, MAKELPARAM(SI(2), SI(2)));

        edit_brush_ = CreateSolidBrush(RGB(pal_.input_bg.GetR(), pal_.input_bg.GetG(), pal_.input_bg.GetB()));
        old_edit_proc_ = reinterpret_cast<WNDPROC>(
            SetWindowLongPtrW(edit_, GWLP_WNDPROC, reinterpret_cast<LONG_PTR>(EditProc)));

        SetWindowTextW(edit_, utf8_to_wide(me_).c_str());
    }

    std::wstring edit_text() const {
        if (!edit_) return std::wstring();
        const int len = GetWindowTextLengthW(edit_);
        if (len <= 0) return std::wstring();
        std::wstring buf(static_cast<size_t>(len) + 1, L'\0');
        GetWindowTextW(edit_, &buf[0], len + 1);
        buf.resize(static_cast<size_t>(len));
        return buf;
    }

    void update_composer_height() {
        if (!edit_ || !joined_) return;
        int lines = static_cast<int>(SendMessageW(edit_, EM_GETLINECOUNT, 0, 0));
        lines = std::clamp(lines, 1, 4);
        const float new_h = lines * S(22) + S(40);
        if (std::fabs(new_h - composer_h_) > 0.5f) {
            composer_h_ = new_h;
            layout();
            invalidate();
        }
    }

    // ---------------------------------------------------------------- 布局
    void layout() {
        RECT rc;
        GetClientRect(hwnd_, &rc);
        w_ = rc.right;
        h_ = rc.bottom;

        if (!joined_) {
            layout_login();
            return;
        }

        const float pad = S(14);
        const float side_w = S(286);

        sidebar_rect_ = RectF(pad, pad, side_w, h_ - pad * 2);
        chat_rect_ = RectF(pad + side_w + pad, pad, w_ - side_w - pad * 3, h_ - pad * 2);

        brand_rect_ = RectF(sidebar_rect_.X, sidebar_rect_.Y, side_w, S(74));
        me_rect_ = RectF(sidebar_rect_.X, sidebar_rect_.GetBottom() - S(70), side_w, S(70));
        members_rect_ = RectF(sidebar_rect_.X, brand_rect_.GetBottom(), side_w,
                              std::max(0.0f, me_rect_.Y - brand_rect_.GetBottom()));

        header_rect_ = RectF(chat_rect_.X, chat_rect_.Y, chat_rect_.Width, S(64));

        composer_rect_ = RectF(chat_rect_.X + S(16),
                               chat_rect_.GetBottom() - S(14) - composer_h_,
                               chat_rect_.Width - S(32),
                               composer_h_);

        const float feed_bottom = composer_rect_.Y - (peer_.empty() ? S(4) : S(46));
        feed_rect_ = RectF(chat_rect_.X + S(4),
                           header_rect_.GetBottom(),
                           chat_rect_.Width - S(8),
                           std::max(S(40), feed_bottom - header_rect_.GetBottom()));

        const float btn = S(40);
        button_rect_ = RectF(composer_rect_.GetRight() - S(12) - btn,
                             composer_rect_.Y + S(10), btn, btn);

        theme_rect_ = RectF(chat_rect_.GetRight() - S(54), chat_rect_.Y + S(16), S(36), S(36));

        if (!peer_.empty()) {
            dm_bar_rect_ = RectF(composer_rect_.X, composer_rect_.Y - S(40),
                                 composer_rect_.Width, S(32));
        } else {
            dm_bar_rect_ = RectF();
        }

        if (edit_) {
            const float edit_h = composer_rect_.Height - S(34);
            MoveWindow(edit_,
                       SI(composer_rect_.X + S(16)),
                       SI(composer_rect_.Y + S(11)),
                       SI(composer_rect_.Width - S(16) - S(64)),
                       SI(edit_h - S(4)), TRUE);
        }

        layout_dirty_ = true;
        reflow();
        clamp_scroll();
    }

    void layout_login() {
        const float card_w = S(392);
        const float card_h = S(348);
        login_card_ = RectF((w_ - card_w) / 2, (h_ - card_h) / 2, card_w, card_h);

        login_input_ = RectF(login_card_.X + S(34), login_card_.Y + S(196),
                             login_card_.Width - S(68), S(46));
        login_button_ = RectF(login_card_.X + S(34), login_card_.Y + S(256),
                              login_card_.Width - S(68), S(46));

        if (edit_) {
            MoveWindow(edit_,
                       SI(login_input_.X + S(14)),
                       SI(login_input_.Y + S(12)),
                       SI(login_input_.Width - S(28)),
                       SI(login_input_.Height - S(18)), TRUE);
        }
    }

    void reflow() {
        if (!layout_dirty_) return;
        const float pad_x = S(14);
        const float pad_y = S(10);
        const float max_bubble = std::min(S(560), std::max(S(180), feed_rect_.Width * 0.66f));
        const float max_text_w = max_bubble - pad_x * 2;

        float y = S(18);
        for (auto& m : messages_) {
            m.top = y;
            if (m.system) {
                m.height = S(40);
            } else {
                if (!m.measured || std::fabs(m.measured_w - max_text_w) > 0.5f) {
                    const RectF b = measure(m.wtext, font_body_, max_text_w);
                    m.text_w = std::min(std::max(b.Width, S(6)), max_text_w);
                    m.text_h = std::max(b.Height, S(18));
                    m.text_layout_w = max_text_w;
                    m.bubble_w = m.text_w + pad_x * 2;
                    m.bubble_h = m.text_h + pad_y * 2;
                    m.meta_h = m.grouped ? 0 : S(19);
                    m.measured = true;
                    m.measured_w = max_text_w;
                }
                m.height = m.meta_h + m.bubble_h + S(15);
            }
            y += m.height;
        }
        content_h_ = y + S(8);
        layout_dirty_ = false;
    }

    RectF measure(const std::wstring& text, Font* font, float max_w) {
        StringFormat fmt(StringFormatFlagsMeasureTrailingSpaces | StringFormatFlagsNoClip);
        fmt.SetTrimming(StringTrimmingNone);
        RectF layout(0, 0, max_w, 100000);
        RectF bounds;
        measure_g_->MeasureString(text.c_str(), static_cast<INT>(text.size()),
                                  font, layout, &fmt, &bounds);
        return bounds;
    }

    void clamp_scroll() {
        const float view_h = feed_rect_.Height;
        const float max_scroll = std::max(0.0f, content_h_ - view_h);
        scroll_y_ = std::clamp(scroll_y_, 0.0f, max_scroll);
    }

    bool at_bottom() const {
        const float max_scroll = std::max(0.0f, content_h_ - feed_rect_.Height);
        return scroll_y_ >= max_scroll - S(24);
    }

    void scroll_to_bottom() {
        scroll_y_ = std::max(0.0f, content_h_ - feed_rect_.Height);
    }

    // ---------------------------------------------------------------- 数据
    void add_message(const std::map<std::string, std::string>& obj) {
        const std::string id = json_get(obj, "id");
        if (!id.empty() && seen_.count(id)) return;
        if (!id.empty()) seen_.insert(id);

        UiMessage m;
        m.id = id;
        m.from = json_get(obj, "from");
        m.text = json_get(obj, "text");
        m.to = json_get(obj, "to");
        m.ts = json_get_int(obj, "ts", now_ms());
        m.mine = (m.from == me_);
        m.history = json_get(obj, "history") == "true";

        const bool stick = at_bottom() || m.history;
        m.grouped = !m.history && !messages_.empty() &&
                    messages_.back().from == m.from && !messages_.back().system &&
                    std::llabs(m.ts - messages_.back().ts) < 120000;

        m.wfrom = utf8_to_wide(m.from);
        m.wtext = utf8_to_wide(m.text);
        m.wtime = format_time_w(m.ts);

        messages_.push_back(std::move(m));
        while (messages_.size() > kMaxMessages) messages_.erase(messages_.begin());

        layout_dirty_ = true;
        reflow();
        if (stick) scroll_to_bottom();
        invalidate();
    }

    void add_system(const std::string& text, const std::string& kind) {
        const bool stick = at_bottom();
        UiMessage m;
        m.system = true;
        m.kind = kind;
        m.text = text;
        m.ts = now_ms();
        m.wtext = utf8_to_wide(text);
        m.wtime = format_time_w(m.ts);
        messages_.push_back(std::move(m));
        while (messages_.size() > kMaxMessages) messages_.erase(messages_.begin());

        layout_dirty_ = true;
        reflow();
        if (stick) scroll_to_bottom();
        invalidate();
    }

    void set_users(const std::string& joined) {
        users_.clear();
        std::string cur;
        for (char c : joined) {
            if (c == '|') {
                if (!cur.empty()) users_.push_back(cur);
                cur.clear();
            } else {
                cur.push_back(c);
            }
        }
        if (!cur.empty()) users_.push_back(cur);

        if (!peer_.empty() &&
            std::find(users_.begin(), users_.end(), peer_) == users_.end()) {
            peer_.clear();
            show_toast(L"对方已离线，已返回大厅");
            layout();
        }
        invalidate();
    }

    void handle_network(const std::string& raw) {
        auto obj = parse_json_object(raw);
        const std::string type = json_get(obj, "type");

        if (type == "welcome") {
            me_ = json_get(obj, "self", me_);
            online_ = true;
            set_users(json_get(obj, "users"));
            if (!welcome_done_) {
                welcome_done_ = true;
                add_system("你已加入聊天室", "join");
            }
            invalidate();
            return;
        }
        if (type == "msg") {
            add_message(obj);
            return;
        }
        if (type == "system") {
            const std::string text = json_get(obj, "text");
            const std::string kind = json_get(obj, "kind");
            // 自己的加入提示已由本地 welcome 处理，避免重复
            if (kind == "join" && text == me_ + " 加入了聊天室") return;
            add_system(text, kind);
            return;
        }
        if (type == "users") {
            set_users(json_get(obj, "users"));
            return;
        }
        if (type == "typing") {
            const std::string from = json_get(obj, "from");
            if (!from.empty() && from != me_) {
                typing_text_ = utf8_to_wide(from) + L" 正在输入…";
                KillTimer(hwnd_, kTypingTimer);
                SetTimer(hwnd_, kTypingTimer, 2600, nullptr);
                invalidate();
            }
            return;
        }
        if (type == "error") {
            show_toast(utf8_to_wide(json_get(obj, "text")));
            return;
        }
        if (type == "pong") {
            if (ping_sent_ > 0) {
                rtt_ = now_ms() - ping_sent_;
                ping_sent_ = 0;
                invalidate();
            }
            return;
        }
    }

    void show_toast(const std::wstring& text) {
        toast_ = text;
        KillTimer(hwnd_, kToastTimer);
        SetTimer(hwnd_, kToastTimer, 2600, nullptr);
        invalidate();
    }

    // ---------------------------------------------------------------- 交互
    void submit_input() {
        if (!joined_) {
            do_join();
            return;
        }
        const std::string text = trim_utf8(wide_to_utf8(edit_text()));
        if (text.empty()) return;

        std::string payload = "{\"type\":\"msg\",\"text\":\"" + json_escape(text) + "\"";
        if (!peer_.empty()) payload += ",\"to\":\"" + json_escape(peer_) + "\"";
        payload += "}";
        client_.send_json(payload);

        SetWindowTextW(edit_, L"");
        update_composer_height();
        scroll_to_bottom();
        invalidate();
    }

    void do_join() {
        std::string name = trim_utf8(wide_to_utf8(edit_text()));
        if (name.empty()) {
            show_toast(L"先给自己起个名字");
            SetFocus(edit_);
            return;
        }
        name = utf8_truncate(name, 16);
        me_ = name;
        joined_ = true;
        client_.send_json("{\"type\":\"join\",\"name\":\"" + json_escape(name) + "\"}");
        SetWindowTextW(edit_, L"");
        layout();
        invalidate();
        SetFocus(edit_);
    }

    void update_hover(float x, float y) {
        const PointF pt(x, y);
        std::string hovered;
        if (joined_) {
            for (const auto& hit : member_hits_) {
                if (hit.first.Contains(pt)) {
                    hovered = hit.second;
                    break;
                }
            }
        }
        const bool send_hover = joined_ && button_rect_.Contains(pt);
        const bool theme_hover = joined_ && theme_rect_.Contains(pt);

        if (hovered != hover_member_ || send_hover != hover_send_ || theme_hover != hover_theme_) {
            hover_member_ = hovered;
            hover_send_ = send_hover;
            hover_theme_ = theme_hover;
            invalidate();
        }
    }

    void on_click(float x, float y) {
        const PointF pt(x, y);
        if (!joined_) {
            if (login_button_.Contains(pt)) do_join();
            return;
        }
        if (theme_rect_.Contains(pt)) {
            dark_ = !dark_;
            pal_ = dark_ ? make_dark() : make_light();
            if (edit_brush_) DeleteObject(edit_brush_);
            edit_brush_ = CreateSolidBrush(RGB(pal_.input_bg.GetR(), pal_.input_bg.GetG(),
                                               pal_.input_bg.GetB()));
            InvalidateRect(edit_, nullptr, TRUE);
            apply_titlebar();
            invalidate();
            return;
        }
        if (button_rect_.Contains(pt)) {
            submit_input();
            return;
        }
        if (!dm_bar_rect_.IsEmptyArea() && dm_bar_rect_.Contains(pt)) {
            peer_.clear();
            layout();
            invalidate();
            return;
        }
        for (const auto& hit : member_hits_) {
            if (hit.first.Contains(pt) && hit.second != me_) {
                peer_ = (peer_ == hit.second) ? std::string() : hit.second;
                layout();
                invalidate();
                SetFocus(edit_);
                return;
            }
        }
    }

    // ---------------------------------------------------------------- 绘制
    void paint() {
        PAINTSTRUCT ps;
        HDC hdc = BeginPaint(hwnd_, &ps);
        if (w_ <= 0 || h_ <= 0) {
            EndPaint(hwnd_, &ps);
            return;
        }

        HDC mem_dc = CreateCompatibleDC(hdc);
        HBITMAP bmp = CreateCompatibleBitmap(hdc, w_, h_);
        HBITMAP old_bmp = static_cast<HBITMAP>(SelectObject(mem_dc, bmp));

        {
            Graphics g(mem_dc);
            g.SetSmoothingMode(SmoothingModeAntiAlias);
            g.SetTextRenderingHint(TextRenderingHintAntiAliasGridFit);
            g.SetPixelOffsetMode(PixelOffsetModeHalf);

            draw_background(g);
            if (joined_) {
                draw_sidebar(g);
                draw_chat(g);
            } else {
                draw_login(g);
            }
            draw_toast(g);
        }

        BitBlt(hdc, 0, 0, w_, h_, mem_dc, 0, 0, SRCCOPY);
        SelectObject(mem_dc, old_bmp);
        DeleteObject(bmp);
        DeleteDC(mem_dc);
        EndPaint(hwnd_, &ps);
    }

    void draw_background(Graphics& g) {
        LinearGradientBrush bg(Rect(0, 0, w_, h_), pal_.bg_top, pal_.bg_bottom,
                               LinearGradientModeVertical);
        g.FillRectangle(&bg, 0, 0, w_, h_);

        GraphicsPath glow;
        glow.AddEllipse(-w_ * 0.32f, -h_ * 0.55f, w_ * 0.95f, h_ * 0.95f);
        PathGradientBrush gb(&glow);
        gb.SetCenterColor(pal_.glow);
        Color surround[] = {Color(0, pal_.accent_a.GetR(), pal_.accent_a.GetG(), pal_.accent_a.GetB())};
        int count = 1;
        gb.SetSurroundColors(surround, &count);
        g.FillPath(&gb, &glow);
    }

    void draw_panel(Graphics& g, const RectF& r, float radius, Color fill, Color border) {
        GraphicsPath p;
        MakeRoundRect(r, radius, p);
        SolidBrush brush(fill);
        g.FillPath(&brush, &p);
        Pen pen(border, 1.0f);
        g.DrawPath(&pen, &p);
    }

    void draw_avatar(Graphics& g, const std::string& name, float x, float y, float size) {
        const auto colors = gradient_of(name);
        const RectF r(x, y, size, size);
        GraphicsPath p;
        MakeRoundRect(r, size * 0.32f, p);
        LinearGradientBrush brush(r, colors.first, colors.second, 45.0f);
        g.FillPath(&brush, &p);

        const std::wstring initial = first_char_w(name);
        StringFormat sf;
        sf.SetAlignment(StringAlignmentCenter);
        sf.SetLineAlignment(StringAlignmentCenter);
        SolidBrush white(Color(255, 255, 255, 255));
        g.DrawString(initial.c_str(), -1, font_avatar_, r, &sf, &white);
    }

    void draw_login(Graphics& g) {
        const RectF card = login_card_;
        draw_panel(g, card, S(26), pal_.panel, pal_.panel_border);

        const float cx = card.X + card.Width / 2;

        // 图标
        const RectF icon(cx - S(27), card.Y + S(38), S(54), S(54));
        GraphicsPath ip;
        MakeRoundRect(icon, S(17), ip);
        LinearGradientBrush ib(icon, pal_.accent_a, pal_.accent_b, 45.0f);
        g.FillPath(&ib, &ip);
        Pen wave(Color(255, 255, 255, 255), S(2.2f));
        wave.SetStartCap(LineCapRound);
        wave.SetEndCap(LineCapRound);
        wave.SetLineJoin(LineJoinRound);
        PointF pts[] = {
            {icon.X + S(13), icon.Y + S(27)},
            {icon.X + S(20), icon.Y + S(27)},
            {icon.X + S(24), icon.Y + S(15)},
            {icon.X + S(31), icon.Y + S(39)},
            {icon.X + S(35), icon.Y + S(27)},
            {icon.X + S(41), icon.Y + S(27)},
        };
        g.DrawLines(&wave, pts, 6);

        StringFormat center;
        center.SetAlignment(StringAlignmentCenter);
        center.SetLineAlignment(StringAlignmentCenter);

        // 标题
        SolidBrush title_brush(pal_.text);
        RectF title_rect(card.X, card.Y + S(106), card.Width, S(38));
        g.DrawString(L"UDPulse", -1, font_hero_, title_rect, &center, &title_brush);

        SolidBrush dim(pal_.text_faint);
        RectF sub_rect(card.X, card.Y + S(146), card.Width, S(24));
        g.DrawString(L"C++ UDP 实时聊天室", -1, font_small_, sub_rect, &center, &dim);

        // 昵称输入框
        draw_panel(g, login_input_, S(13), pal_.input_bg, pal_.input_border);

        // 按钮
        GraphicsPath bp;
        MakeRoundRect(login_button_, S(13), bp);
        LinearGradientBrush bb(login_button_, pal_.accent_a, pal_.accent_b, 0.0f);
        g.FillPath(&bb, &bp);

        SolidBrush btn_text(Color(255, 255, 255, 255));
        StringFormat bf;
        bf.SetAlignment(StringAlignmentCenter);
        bf.SetLineAlignment(StringAlignmentCenter);
        g.DrawString(L"进入聊天室", -1, font_title_, login_button_, &bf, &btn_text);

        // 底部信息
        SolidBrush foot(pal_.text_faint);
        RectF fr(card.X, card.Y + card.Height - S(44), card.Width, S(24));
        const std::wstring info = utf8_to_wide("UDP " + std::to_string(opt_.port) +
                                               (opt_.hosted ? " · 本机已开启服务" : " · 已连接 " + opt_.host));
        g.DrawString(info.c_str(), -1, font_hint_, fr, &center, &foot);
    }

    void draw_sidebar(Graphics& g) {
        draw_panel(g, sidebar_rect_, S(24), pal_.panel, pal_.panel_border);

        // 品牌
        const float bx = sidebar_rect_.X + S(18);
        const float by = sidebar_rect_.Y + S(20);
        const RectF icon(bx, by, S(38), S(38));
        GraphicsPath ip;
        MakeRoundRect(icon, S(12), ip);
        LinearGradientBrush ib(icon, pal_.accent_a, pal_.accent_b, 45.0f);
        g.FillPath(&ib, &ip);
        Pen wave(Color(255, 255, 255, 255), S(1.8f));
        wave.SetStartCap(LineCapRound);
        wave.SetEndCap(LineCapRound);
        wave.SetLineJoin(LineJoinRound);
        PointF pts[] = {
            {icon.X + S(9), icon.Y + S(19)},
            {icon.X + S(14), icon.Y + S(19)},
            {icon.X + S(17), icon.Y + S(11)},
            {icon.X + S(22), icon.Y + S(27)},
            {icon.X + S(25), icon.Y + S(19)},
            {icon.X + S(29), icon.Y + S(19)},
        };
        g.DrawLines(&wave, pts, 6);

        SolidBrush brand(pal_.text);
        g.DrawString(L"UDPulse", -1, font_brand_, PointF(bx + S(50), by + S(1)), &brand);

        SolidBrush sub(pal_.text_faint);
        g.DrawString(L"C++ UDP CHAT", -1, font_hint_, PointF(bx + S(50), by + S(22)), &sub);

        // 在线成员标题
        const float head_y = members_rect_.Y + S(6);
        SolidBrush head(pal_.text_faint);
        g.DrawString(L"在线成员", -1, font_hint_, PointF(sidebar_rect_.X + S(20), head_y), &head);

        wchar_t count_buf[16];
        std::swprintf(count_buf, 16, L"%d", static_cast<int>(users_.size()));
        SolidBrush count_brush(pal_.text_dim);
        RectF count_rect(sidebar_rect_.GetRight() - S(58), head_y - S(2), S(40), S(18));
        StringFormat right;
        right.SetAlignment(StringAlignmentFar);
        g.DrawString(count_buf, -1, font_hint_, count_rect, &right, &count_brush);

        // 成员列表
        member_hits_.clear();
        float my = members_rect_.Y + S(34);
        const float item_h = S(40);
        const float list_bottom = me_rect_.Y - S(6);

        for (const auto& name : users_) {
            if (my + item_h > list_bottom) break;
            const RectF row(sidebar_rect_.X + S(10), my,
                            sidebar_rect_.Width - S(20), item_h - S(2));
            if (name == peer_ || name == hover_member_) {
                GraphicsPath rp;
        MakeRoundRect(row, S(11), rp);
                SolidBrush rb(name == peer_ ? pal_.input_bg : pal_.hover);
                g.FillPath(&rb, &rp);
            }

            draw_avatar(g, name, row.X + S(8), my + S(4), S(30));

            SolidBrush nb(name == me_ ? pal_.text_dim : pal_.text);
            RectF nr(row.X + S(46), my + S(9), row.Width - S(70), S(22));
            StringFormat nf;
            nf.SetTrimming(StringTrimmingEllipsisCharacter);
            nf.SetFormatFlags(StringFormatFlagsNoWrap);
            g.DrawString(utf8_to_wide(name).c_str(), -1, font_member_, nr, &nf, &nb);

            if (name == me_) {
                SolidBrush tag(pal_.text_faint);
                RectF tr(row.X + S(46), my + S(25), row.Width - S(70), S(14));
                g.DrawString(L"我", -1, font_hint_, tr, &nf, &tag);
            }

            // 在线点
            SolidBrush dot(pal_.success);
            g.FillEllipse(&dot, row.GetRight() - S(20), my + S(16), S(6), S(6));

            member_hits_.emplace_back(row, name);
            my += item_h;
        }

        if (users_.empty()) {
            SolidBrush empty(pal_.text_faint);
            RectF er(sidebar_rect_.X + S(20), members_rect_.Y + S(44),
                     sidebar_rect_.Width - S(40), S(40));
            g.DrawString(L"等待其他人加入…", -1, font_hint_, er, nullptr, &empty);
        }

        // 分隔线
        Pen sep(pal_.panel_border, 1.0f);
        g.DrawLine(&sep, sidebar_rect_.X + S(14), me_rect_.Y,
                   sidebar_rect_.GetRight() - S(14), me_rect_.Y);

        // 自己
        draw_avatar(g, me_, sidebar_rect_.X + S(20), me_rect_.Y + S(17), S(38));

        SolidBrush me_name(pal_.text);
        g.DrawString(utf8_to_wide(me_).c_str(), -1, font_name_,
                     PointF(sidebar_rect_.X + S(68), me_rect_.Y + S(18)), &me_name);

        SolidBrush status(pal_.text_faint);
        g.DrawString(online_ ? L"在线" : L"连接中…", -1, font_hint_,
                     PointF(sidebar_rect_.X + S(68), me_rect_.Y + S(38)), &status);

        SolidBrush dot(online_ ? pal_.success : pal_.warn);
        g.FillEllipse(&dot, sidebar_rect_.X + S(50), me_rect_.Y + S(45), S(6), S(6));
    }

    void draw_chat(Graphics& g) {
        draw_panel(g, chat_rect_, S(24), pal_.panel, pal_.panel_border);

        // 顶栏
        const float hx = chat_rect_.X + S(24);
        const float hy = chat_rect_.Y + S(14);

        SolidBrush title(pal_.text);
        const std::wstring room = peer_.empty() ? std::wstring(L"# 大厅")
                                                : (L"@ " + utf8_to_wide(peer_));
        g.DrawString(room.c_str(), -1, font_title_, PointF(hx, hy), &title);

        SolidBrush sub(pal_.text_faint);
        const std::wstring subtitle = utf8_to_wide(
            std::to_string(users_.size()) + " 人在线 · UDP " + std::to_string(opt_.port) +
            (opt_.hosted ? " · 本机服务" : ""));
        g.DrawString(subtitle.c_str(), -1, font_hint_, PointF(hx, hy + S(24)), &sub);

        // 右侧状态
        const float pill_h = S(28);
        float pill_x = chat_rect_.GetRight() - S(64);

        if (rtt_ >= 0) {
            wchar_t rtt_buf[32];
            std::swprintf(rtt_buf, 32, L"%lld ms", static_cast<long long>(rtt_));
            const RectF rb = measure(rtt_buf, font_hint_, S(200));
            const float pw = rb.Width + S(20);
            const RectF pr(pill_x - pw, chat_rect_.Y + S(18), pw, pill_h);
            draw_panel(g, pr, pill_h / 2, pal_.input_bg, pal_.panel_border);
            SolidBrush tb(pal_.text_faint);
            StringFormat cf;
            cf.SetAlignment(StringAlignmentCenter);
            cf.SetLineAlignment(StringAlignmentCenter);
            g.DrawString(rtt_buf, -1, font_hint_, pr, &cf, &tb);
            pill_x = pr.X - S(8);
        }

        {
            const wchar_t* label = online_ ? L"已连接" : L"连接中";
            const RectF lb = measure(label, font_hint_, S(200));
            const float pw = lb.Width + S(30);
            const RectF pr(pill_x - pw, chat_rect_.Y + S(18), pw, pill_h);
            draw_panel(g, pr, pill_h / 2, pal_.input_bg, pal_.panel_border);
            SolidBrush db(online_ ? pal_.success : pal_.warn);
            g.FillEllipse(&db, pr.X + S(11), pr.Y + pill_h / 2 - S(3), S(6), S(6));
            SolidBrush tb(pal_.text_dim);
            RectF tr(pr.X + S(22), pr.Y, pr.Width - S(26), pill_h);
            StringFormat lf;
            lf.SetLineAlignment(StringAlignmentCenter);
            g.DrawString(label, -1, font_hint_, tr, &lf, &tb);
        }

        // 消息区
        g.SetClip(RectF(feed_rect_.X, feed_rect_.Y, feed_rect_.Width, feed_rect_.Height));
        for (const auto& m : messages_) {
            const float y = feed_rect_.Y + m.top - scroll_y_;
            if (y + m.height < feed_rect_.Y - S(4)) continue;
            if (y > feed_rect_.GetBottom() + S(4)) break;
            if (m.system) draw_system(g, m, y);
            else draw_message(g, m, y);
        }
        g.ResetClip();

        // 滚动条
        if (content_h_ > feed_rect_.Height + 1) {
            const float track_h = feed_rect_.Height - S(8);
            const float ratio = feed_rect_.Height / content_h_;
            const float thumb_h = std::max(S(28), track_h * ratio);
            const float max_scroll = content_h_ - feed_rect_.Height;
            const float t = max_scroll > 0 ? scroll_y_ / max_scroll : 0;
            const float thumb_y = feed_rect_.Y + S(4) + (track_h - thumb_h) * t;
            const RectF thumb(feed_rect_.GetRight() - S(7), thumb_y, S(4), thumb_h);
            GraphicsPath tp;
        MakeRoundRect(thumb, S(2), tp);
            SolidBrush tb(pal_.scroll_thumb);
            g.FillPath(&tb, &tp);
        }

        // 输入中提示
        if (!typing_text_.empty()) {
            SolidBrush tb(pal_.text_faint);
            g.DrawString(typing_text_.c_str(), -1, font_hint_,
                         PointF(feed_rect_.X + S(22), composer_rect_.Y - S(22)), &tb);
        }

        // 私聊条
        if (!peer_.empty()) {
            const RectF bar = dm_bar_rect_;
            draw_panel(g, bar, S(10), pal_.input_bg, pal_.panel_border);
            SolidBrush tb(pal_.text_dim);
            RectF tr(bar.X + S(14), bar.Y, bar.Width - S(110), bar.Height);
            StringFormat lf;
            lf.SetLineAlignment(StringAlignmentCenter);
            g.DrawString((L"私聊 " + utf8_to_wide(peer_)).c_str(), -1, font_hint_, tr, &lf, &tb);

            SolidBrush xb(pal_.text_faint);
            RectF xr(bar.GetRight() - S(96), bar.Y, S(84), bar.Height);
            StringFormat rf;
            rf.SetAlignment(StringAlignmentFar);
            rf.SetLineAlignment(StringAlignmentCenter);
            g.DrawString(L"返回大厅", -1, font_hint_, xr, &rf, &xb);
        }

        // 输入区
        draw_panel(g, composer_rect_, S(18), pal_.input_bg, pal_.input_border);

        // 发送按钮
        {
            const RectF btn = button_rect_;
            GraphicsPath bp;
        MakeRoundRect(btn, S(13), bp);
            if (hover_send_) {
                LinearGradientBrush bb(btn, Color(255, 124, 128, 255), Color(255, 160, 116, 255), 45.0f);
                g.FillPath(&bb, &bp);
            } else {
                LinearGradientBrush bb(btn, pal_.accent_a, pal_.accent_b, 45.0f);
                g.FillPath(&bb, &bp);
            }
            const float cx = btn.X + btn.Width / 2;
            const float cy = btn.Y + btn.Height / 2;
            PointF plane[] = {
                {cx - S(9), cy + S(1)},
                {cx + S(9), cy - S(7)},
                {cx + S(2), cy + S(1)},
                {cx + S(9), cy + S(9)},
            };
            SolidBrush pb(Color(255, 255, 255, 255));
            g.FillPolygon(&pb, plane, 4);
        }

        // 底部提示
        SolidBrush hint(pal_.text_faint);
        g.DrawString(L"Enter 发送 · Shift + Enter 换行", -1, font_hint_,
                     PointF(composer_rect_.X + S(18), composer_rect_.GetBottom() - S(20)), &hint);

        wchar_t cnt[32];
        std::swprintf(cnt, 32, L"%d / 1200", static_cast<int>(edit_text().size()));
        RectF cr(composer_rect_.GetRight() - S(150), composer_rect_.GetBottom() - S(20), S(132), S(16));
        StringFormat rf;
        rf.SetAlignment(StringAlignmentFar);
        g.DrawString(cnt, -1, font_hint_, cr, &rf, &hint);

        // 主题切换按钮（画在面板之上）
        {
            GraphicsPath tp;
            MakeRoundRect(theme_rect_, S(11), tp);
            if (hover_theme_) {
                SolidBrush hb(pal_.hover);
                g.FillPath(&hb, &tp);
            }
            Pen pen(pal_.text_dim, S(1.6f));
            pen.SetStartCap(LineCapRound);
            pen.SetEndCap(LineCapRound);
            const float cx = theme_rect_.X + theme_rect_.Width / 2;
            const float cy = theme_rect_.Y + theme_rect_.Height / 2;
            if (dark_) {
                const float r = S(6.5f);
                g.DrawEllipse(&pen, cx - r, cy - r, r * 2, r * 2);
                for (int i = 0; i < 8; ++i) {
                    const float a = i * 3.14159265f / 4;
                    const float x1 = cx + std::cos(a) * S(10);
                    const float y1 = cy + std::sin(a) * S(10);
                    const float x2 = cx + std::cos(a) * S(13);
                    const float y2 = cy + std::sin(a) * S(13);
                    g.DrawLine(&pen, x1, y1, x2, y2);
                }
            } else {
                const float r = S(9);
                GraphicsPath moon;
                moon.AddEllipse(cx - r, cy - r, r * 2, r * 2);
                GraphicsPath cut;
                cut.AddEllipse(cx - r + S(6), cy - r - S(3), r * 2, r * 2);
                Region region(&moon);
                Region cut_region(&cut);
                region.Exclude(&cut_region);
                SolidBrush mb(pal_.text_dim);
                g.FillRegion(&mb, &region);
            }
        }
    }

    void draw_system(Graphics& g, const UiMessage& m, float y) {
        const RectF tb = measure(m.wtext, font_small_, feed_rect_.Width * 0.8f);
        const float w = std::min(tb.Width + S(26), feed_rect_.Width - S(60));
        const float h = S(26);
        const RectF r(feed_rect_.X + (feed_rect_.Width - w) / 2, y + S(7), w, h);

        GraphicsPath p;
        MakeRoundRect(r, h / 2, p);
        SolidBrush fill(pal_.sys_bg);
        g.FillPath(&fill, &p);
        Pen pen(pal_.sys_border, 1.0f);
        g.DrawPath(&pen, &p);

        StringFormat sf;
        sf.SetAlignment(StringAlignmentCenter);
        sf.SetLineAlignment(StringAlignmentCenter);
        SolidBrush tb_brush(pal_.text_faint);
        g.DrawString(m.wtext.c_str(), -1, font_small_, r, &sf, &tb_brush);
    }

    void draw_message(Graphics& g, const UiMessage& m, float y) {
        const float avatar = S(34);
        const float gap = S(11);
        const float left = feed_rect_.X + S(22);
        const float right = feed_rect_.GetRight() - S(22);

        const float avatar_x = m.mine ? right - avatar : left;
        const float bubble_x = m.mine ? avatar_x - gap - m.bubble_w : avatar_x + avatar + gap;
        const float bubble_y = y + m.meta_h;

        // 头像
        if (!m.grouped) {
            draw_avatar(g, m.from, avatar_x, bubble_y, avatar);
        }

        // 名字与时间
        if (!m.grouped) {
            const std::wstring label = m.mine ? L"我" : m.wfrom;
            std::wstring time = m.wtime;
            if (!m.to.empty()) {
                if (m.mine) time += std::wstring(L" · 私聊 → ") + utf8_to_wide(m.to);
                else time += L" · 私聊";
            }

            const RectF nb = measure(label, font_name_, S(240));
            const float name_x = m.mine ? (bubble_x + m.bubble_w - nb.Width) : bubble_x;
            SolidBrush name_brush(pal_.text_dim);
            g.DrawString(label.c_str(), -1, font_name_, PointF(name_x, y + S(1)), &name_brush);

            const RectF tb = measure(time, font_small_, S(300));
            const float time_x = m.mine ? (name_x - S(8) - tb.Width) : (name_x + nb.Width + S(8));
            SolidBrush time_brush(pal_.text_faint);
            g.DrawString(time.c_str(), -1, font_small_, PointF(time_x, y + S(2)), &time_brush);
        }

        // 气泡
        const RectF br(bubble_x, bubble_y, m.bubble_w, m.bubble_h);
        GraphicsPath path;
        MakeBubble(br, S(16), S(5), m.mine, path);

        if (m.mine) {
            LinearGradientBrush brush(br, pal_.accent_a, pal_.accent_b, 45.0f);
            g.FillPath(&brush, &path);
        } else {
            SolidBrush fill(pal_.bubble_in);
            g.FillPath(&fill, &path);
            Pen pen(pal_.bubble_border, 1.0f);
            g.DrawPath(&pen, &path);
        }

        // 文本
        StringFormat tf(StringFormatFlagsMeasureTrailingSpaces | StringFormatFlagsNoClip);
        tf.SetTrimming(StringTrimmingNone);
        RectF tr(bubble_x + S(14), bubble_y + S(10), m.text_layout_w, m.text_h);
        SolidBrush text_brush(m.mine ? Color(255, 255, 255, 255) : pal_.text);
        g.DrawString(m.wtext.c_str(), -1, font_body_, tr, &tf, &text_brush);
    }

    void draw_toast(Graphics& g) {
        if (toast_.empty()) return;
        const RectF tb = measure(toast_, font_small_, S(520));
        const float w = tb.Width + S(36);
        const float h = S(38);
        const RectF r((w_ - w) / 2, h_ - S(74), w, h);

        GraphicsPath p;
        MakeRoundRect(r, h / 2, p);
        SolidBrush fill(Color(240, 18, 24, 36));
        g.FillPath(&fill, &p);
        Pen pen(Color(60, 255, 255, 255), 1.0f);
        g.DrawPath(&pen, &p);

        StringFormat sf;
        sf.SetAlignment(StringAlignmentCenter);
        sf.SetLineAlignment(StringAlignmentCenter);
        SolidBrush tb_brush(Color(255, 241, 245, 249));
        g.DrawString(toast_.c_str(), -1, font_small_, r, &sf, &tb_brush);
    }

    // ---------------------------------------------------------------- 状态
    HINSTANCE inst_ = nullptr;
    HWND hwnd_ = nullptr;
    HWND edit_ = nullptr;
    WNDPROC old_edit_proc_ = nullptr;
    HBRUSH edit_brush_ = nullptr;
    HFONT edit_font_ = nullptr;

    ChatClient& client_;
    ChatServer* server_ = nullptr;
    UiOptions opt_;

    float scale_ = 1.0f;
    int dpi_ = 96;
    int w_ = 0, h_ = 0;

    Palette pal_;
    bool dark_ = true;

    std::string me_;
    std::string peer_;
    std::vector<std::string> users_;
    std::vector<UiMessage> messages_;
    std::unordered_set<std::string> seen_;
    bool joined_ = false;
    bool online_ = false;
    bool welcome_done_ = false;

    bool layout_dirty_ = true;
    float content_h_ = 0;
    float scroll_y_ = 0;
    float composer_h_ = 0;

    int64_t ping_sent_ = 0;
    int64_t rtt_ = -1;

    RectF sidebar_rect_, chat_rect_, header_rect_, feed_rect_, composer_rect_;
    RectF button_rect_, theme_rect_, dm_bar_rect_, brand_rect_, me_rect_, members_rect_;
    RectF login_card_, login_input_, login_button_;
    std::vector<std::pair<RectF, std::string>> member_hits_;

    std::wstring toast_;
    std::wstring typing_text_;
    std::string hover_member_;
    bool hover_send_ = false;
    bool hover_theme_ = false;

    Font* font_body_ = nullptr;
    Font* font_small_ = nullptr;
    Font* font_name_ = nullptr;
    Font* font_title_ = nullptr;
    Font* font_brand_ = nullptr;
    Font* font_member_ = nullptr;
    Font* font_avatar_ = nullptr;
    Font* font_hint_ = nullptr;
    Font* font_hero_ = nullptr;
    Bitmap* measure_bmp_ = nullptr;
    Graphics* measure_g_ = nullptr;
};

}  // namespace

int run_ui(HINSTANCE inst, int nCmdShow, ChatClient& client, ChatServer* server, const UiOptions& opt) {
    ChatApp app(inst, client, server, opt);
    return app.run(nCmdShow);
}

}  // namespace chat
