#include "chat_client.h"

namespace chat {

ChatClient::~ChatClient() { close(); }

bool ChatClient::connect_to(const std::string& host, uint16_t port) {
    close();

    sock_ = ::socket(AF_INET, SOCK_DGRAM, 0);
    if (!socket_valid(sock_)) return false;

    server_ = sockaddr_in{};
    server_.sin_family = AF_INET;
    server_.sin_port = htons(port);
    if (inet_pton(AF_INET, host.c_str(), &server_.sin_addr) != 1) {
        socket_close(sock_);
        sock_ = kInvalidSocket;
        return false;
    }

    set_recv_timeout(sock_, 200);
    server_host_ = host;
    server_port_ = port;

    running_ = true;
    connected_ = true;
    thread_ = std::thread(&ChatClient::recv_loop, this);
    return true;
}

void ChatClient::set_handler(Handler handler) {
    std::lock_guard<std::mutex> lock(handler_mtx_);
    handler_ = std::move(handler);
}

void ChatClient::send_json(const std::string& payload) {
    if (!socket_valid(sock_)) return;
    ::sendto(sock_, payload.data(), static_cast<int>(payload.size()), 0,
             reinterpret_cast<const sockaddr*>(&server_), static_cast<sock_len_t>(sizeof(server_)));
}

void ChatClient::close() {
    running_ = false;
    connected_ = false;
    if (socket_valid(sock_)) {
        socket_close(sock_);
        sock_ = kInvalidSocket;
    }
    if (thread_.joinable()) thread_.join();
}

void ChatClient::recv_loop() {
    char buf[8192];
    while (running_) {
        sockaddr_in from{};
        sock_len_t len = static_cast<sock_len_t>(sizeof(from));
        const int n = static_cast<int>(::recvfrom(sock_, buf, static_cast<int>(sizeof(buf) - 1), 0,
                                                  reinterpret_cast<sockaddr*>(&from), &len));
        if (n > 0) {
            buf[n] = '\0';
            Handler fn;
            {
                std::lock_guard<std::mutex> lock(handler_mtx_);
                fn = handler_;
            }
            if (fn) fn(std::string(buf, static_cast<size_t>(n)));
        }
    }
}

}  // namespace chat
