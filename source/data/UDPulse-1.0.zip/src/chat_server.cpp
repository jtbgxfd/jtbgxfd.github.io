#include "chat_server.h"

#include <algorithm>
#include <set>
#include <sstream>

namespace chat {

namespace {

std::string trim_copy(const std::string& s) {
    size_t b = 0, e = s.size();
    while (b < e && (s[b] == ' ' || s[b] == '\t' || s[b] == '\r' || s[b] == '\n')) ++b;
    while (e > b && (s[e - 1] == ' ' || s[e - 1] == '\t' || s[e - 1] == '\r' || s[e - 1] == '\n')) --e;
    return s.substr(b, e - b);
}

bool same_addr(const sockaddr_in& a, const sockaddr_in& b) {
    return a.sin_addr.s_addr == b.sin_addr.s_addr && a.sin_port == b.sin_port;
}

std::string message_json(const std::string& id, const std::string& from, const std::string& text,
                         const std::string& to, int64_t ts, bool history) {
    std::string out;
    out.reserve(text.size() + 120);
    out += "{\"type\":\"msg\",\"id\":\"";
    out += json_escape(id);
    out += "\",\"from\":\"";
    out += json_escape(from);
    out += "\",\"text\":\"";
    out += json_escape(text);
    out += "\",\"to\":\"";
    out += json_escape(to);
    out += "\",\"ts\":";
    out += std::to_string(ts);
    if (history) out += ",\"history\":true";
    out += "}";
    return out;
}

std::string system_json(const std::string& text, const std::string& kind) {
    std::string out = "{\"type\":\"system\",\"text\":\"";
    out += json_escape(text);
    out += "\",\"kind\":\"";
    out += json_escape(kind);
    out += "\",\"ts\":";
    out += std::to_string(now_ms());
    out += "}";
    return out;
}

std::string error_json(const std::string& text) {
    std::string out = "{\"type\":\"error\",\"text\":\"";
    out += json_escape(text);
    out += "\",\"ts\":";
    out += std::to_string(now_ms());
    out += "}";
    return out;
}

}  // namespace

ChatServer::ChatServer(ServerConfig cfg) : cfg_(cfg) {}

ChatServer::~ChatServer() { stop(); }

void ChatServer::set_logger(Logger logger) {
    std::lock_guard<std::mutex> lock(logger_mtx_);
    logger_ = std::move(logger);
}

void ChatServer::log(const std::string& tag, const std::string& text) {
    Logger fn;
    {
        std::lock_guard<std::mutex> lock(logger_mtx_);
        fn = logger_;
    }
    if (fn) fn("[" + tag + "] " + text);
}

bool ChatServer::start() {
    if (running_) return true;

    sock_ = ::socket(AF_INET, SOCK_DGRAM, 0);
    if (!socket_valid(sock_)) {
        log("ERR", "创建 UDP socket 失败");
        return false;
    }
    set_reuseaddr(sock_);

    sockaddr_in addr{};
    addr.sin_family = AF_INET;
    addr.sin_port = htons(cfg_.port);
    addr.sin_addr.s_addr = htonl(INADDR_ANY);
    if (::bind(sock_, reinterpret_cast<sockaddr*>(&addr), sizeof(addr)) != 0) {
        log("ERR", "UDP 端口 " + std::to_string(cfg_.port) + " 被占用，转为仅客户端模式");
        socket_close(sock_);
        sock_ = kInvalidSocket;
        return false;
    }

    set_recv_timeout(sock_, 200);
    running_ = true;
    thread_ = std::thread(&ChatServer::udp_loop, this);
    log("SYS", "UDP 聊天服务器已启动，端口 " + std::to_string(cfg_.port));
    return true;
}

void ChatServer::stop() {
    if (!running_.exchange(false)) {
        if (thread_.joinable()) thread_.join();
        return;
    }
    if (socket_valid(sock_)) {
        socket_close(sock_);
        sock_ = kInvalidSocket;
    }
    if (thread_.joinable()) thread_.join();

    std::lock_guard<std::recursive_mutex> lock(mtx_);
    peers_.clear();
    history_.clear();
}

void ChatServer::udp_loop() {
    char buf[8192];
    int64_t last_gc = now_ms();

    while (running_) {
        sockaddr_in from{};
        sock_len_t len = static_cast<sock_len_t>(sizeof(from));
        const int n = static_cast<int>(::recvfrom(sock_, buf, static_cast<int>(sizeof(buf) - 1), 0,
                                                  reinterpret_cast<sockaddr*>(&from), &len));
        if (n > 0) {
            buf[n] = '\0';
            std::lock_guard<std::recursive_mutex> lock(mtx_);
            handle_packet_locked(std::string(buf, static_cast<size_t>(n)), from);
        }

        if (now_ms() - last_gc > 5000) {
            last_gc = now_ms();
            gc_peers();
        }
    }
}

void ChatServer::gc_peers() {
    std::vector<std::string> gone;
    {
        std::lock_guard<std::recursive_mutex> lock(mtx_);
        const int64_t now = now_ms();
        for (auto it = peers_.begin(); it != peers_.end();) {
            if (now - it->second.last_seen > cfg_.peer_timeout_ms) {
                gone.push_back(it->first);
                it = peers_.erase(it);
            } else {
                ++it;
            }
        }
        for (const auto& name : gone) {
            broadcast_locked(system_json(name + " 离线了", "leave"));
        }
        if (!gone.empty()) broadcast_users_locked();
    }
    for (const auto& name : gone) log("UDP", name + " 心跳超时");
}

size_t ChatServer::online_count() const {
    std::lock_guard<std::recursive_mutex> lock(mtx_);
    return online_names_locked().size();
}

void ChatServer::broadcast_notice(const std::string& text) {
    std::lock_guard<std::recursive_mutex> lock(mtx_);
    Message m;
    m.id = next_id_locked();
    m.from = "管理员";
    m.text = text;
    m.ts = now_ms();
    push_history_locked(m);
    broadcast_locked(message_json(m.id, m.from, m.text, m.to, m.ts, false));
    log("ADMIN", text);
}

// ---------------------------------------------------------------- 消息处理
void ChatServer::handle_packet_locked(const std::string& raw, const sockaddr_in& from) {
    auto obj = parse_json_object(raw);
    const std::string type = json_get(obj, "type");
    if (type.empty()) return;

    std::string sender;
    auto peer_it = peers_.end();
    for (auto it = peers_.begin(); it != peers_.end(); ++it) {
        if (same_addr(it->second.addr, from)) {
            sender = it->first;
            peer_it = it;
            it->second.last_seen = now_ms();
            break;
        }
    }

    auto reply = [&](const std::string& data) { send_udp(from, data); };

    if (type == "join") {
        const std::string requested = sanitize_name(json_get(obj, "name"));
        const std::string old_name = sender;

        if (!old_name.empty()) peers_.erase(old_name);
        const std::string final_name = unique_name_locked(requested, old_name);

        Peer peer;
        peer.name = final_name;
        peer.addr = from;
        peer.last_seen = now_ms();
        peers_[final_name] = peer;

        reply(welcome_json_locked(final_name));

        const size_t start = history_.size() > cfg_.history_replay
                                 ? history_.size() - cfg_.history_replay
                                 : 0;
        for (size_t i = start; i < history_.size(); ++i) {
            const Message& m = history_[i];
            reply(message_json(m.id, m.from, m.text, m.to, m.ts, true));
        }

        if (old_name.empty()) {
            broadcast_locked(system_json(final_name + " 加入了聊天室", "join"));
            log("JOIN", final_name);
        } else if (old_name != final_name) {
            broadcast_locked(system_json(old_name + " 改名为 " + final_name, "info"));
        }
        broadcast_users_locked();
        return;
    }

    if (type == "ping") {
        reply("{\"type\":\"pong\",\"ts\":" + std::to_string(now_ms()) + "}");
        return;
    }

    if (type == "typing") {
        if (sender.empty()) return;
        broadcast_locked("{\"type\":\"typing\",\"from\":\"" + json_escape(sender) + "\"}", sender);
        return;
    }

    if (type == "leave") {
        if (!sender.empty()) {
            peers_.erase(sender);
            broadcast_locked(system_json(sender + " 离开了聊天室", "leave"));
            broadcast_users_locked();
            log("LEAVE", sender);
        }
        return;
    }

    if (type == "msg") {
        if (sender.empty()) {
            reply(error_json("请先设置昵称再加入聊天室"));
            return;
        }
        std::string text = trim_copy(json_get(obj, "text"));
        text = utf8_truncate(text, 1200);
        if (text.empty()) return;

        const std::string to_raw = trim_copy(json_get(obj, "to"));
        const std::string to = to_raw.empty() ? std::string() : sanitize_name(to_raw);

        Message m;
        m.id = next_id_locked();
        m.from = sender;
        m.text = text;
        m.to = to;
        m.ts = now_ms();

        if (to.empty()) {
            push_history_locked(m);
            broadcast_locked(message_json(m.id, m.from, m.text, m.to, m.ts, false));
            log("MSG", sender + ": " + text);
        } else {
            const bool delivered = send_to_name_locked(to, message_json(m.id, m.from, m.text, m.to, m.ts, false));
            if (to != sender) send_to_name_locked(sender, message_json(m.id, m.from, m.text, m.to, m.ts, false));
            if (!delivered) reply(error_json("「" + to + "」不在线"));
            log("DM", sender + " -> " + to + ": " + text);
        }
    }
}

std::string ChatServer::welcome_json_locked(const std::string& name) {
    const auto names = online_names_locked();
    std::string joined;
    for (size_t i = 0; i < names.size(); ++i) {
        if (i) joined += "|";
        joined += names[i];
    }
    std::string out;
    out.reserve(180);
    out += "{\"type\":\"welcome\",\"self\":\"";
    out += json_escape(name);
    out += "\",\"online\":";
    out += std::to_string(names.size());
    out += ",\"users\":\"";
    out += json_escape(joined);
    out += "\",\"port\":";
    out += std::to_string(cfg_.port);
    out += ",\"history\":";
    out += std::to_string(std::min(history_.size(), cfg_.history_replay));
    out += "}";
    return out;
}

// ------------------------------------------------------------------ 广播
void ChatServer::broadcast_locked(const std::string& data, const std::string& skip_name) {
    for (auto& kv : peers_) {
        if (!skip_name.empty() && kv.first == skip_name) continue;
        send_udp(kv.second.addr, data);
    }
}

bool ChatServer::send_to_name_locked(const std::string& name, const std::string& data) {
    auto it = peers_.find(name);
    if (it == peers_.end()) return false;
    send_udp(it->second.addr, data);
    return true;
}

void ChatServer::send_udp(const sockaddr_in& addr, const std::string& data) {
    if (!socket_valid(sock_)) return;
    ::sendto(sock_, data.data(), static_cast<int>(data.size()), 0,
             reinterpret_cast<const sockaddr*>(&addr), static_cast<sock_len_t>(sizeof(addr)));
}

void ChatServer::broadcast_users_locked() {
    const auto names = online_names_locked();
    std::string joined;
    for (size_t i = 0; i < names.size(); ++i) {
        if (i) joined += "|";
        joined += names[i];
    }
    std::string out = "{\"type\":\"users\",\"users\":\"";
    out += json_escape(joined);
    out += "\",\"online\":";
    out += std::to_string(names.size());
    out += "}";
    broadcast_locked(out);
}

std::vector<std::string> ChatServer::online_names_locked() const {
    std::vector<std::string> names;
    names.reserve(peers_.size());
    for (const auto& kv : peers_) names.push_back(kv.first);
    return names;
}

std::string ChatServer::unique_name_locked(const std::string& base, const std::string& self) {
    auto taken = [&](const std::string& candidate) {
        if (candidate == self) return false;
        return peers_.find(candidate) != peers_.end();
    };
    if (!taken(base)) return base;
    for (int i = 2; i < 100; ++i) {
        const std::string candidate = utf8_truncate(base, 13) + std::to_string(i);
        if (!taken(candidate)) return candidate;
    }
    return utf8_truncate(base, 10) + std::to_string(now_ms() % 1000);
}

std::string ChatServer::sanitize_name(const std::string& raw) {
    std::string out;
    for (unsigned char c : raw) {
        if (c < 0x20 || c == 0x7F) continue;
        if (c == '|' || c == ',' || c == '"' || c == '\\' || c == '<' || c == '>') continue;
        out.push_back(static_cast<char>(c));
    }
    out = trim_copy(out);
    out = utf8_truncate(out, 16);
    if (out.empty()) out = "游客";
    return out;
}

std::string ChatServer::next_id_locked() {
    return "m" + std::to_string(now_ms()) + "-" + std::to_string(counter_++);
}

void ChatServer::push_history_locked(const Message& m) {
    history_.push_back(m);
    while (history_.size() > cfg_.max_history) history_.pop_front();
}

}  // namespace chat
