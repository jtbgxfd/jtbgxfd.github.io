#pragma once
// ============================================================================
//  ChatServer · 纯 UDP 聊天服务器
//  单线程接收 + 广播，可嵌入 GUI 进程，也可独立控制台运行
// ============================================================================
#include "common.h"

#include <atomic>
#include <deque>
#include <functional>
#include <map>
#include <mutex>
#include <string>
#include <thread>
#include <vector>

namespace chat {

struct ServerConfig {
    uint16_t port = 9000;
    size_t max_history = 200;      // 内存中保留的历史条数
    size_t history_replay = 80;    // 新成员加入时补发的条数
    int64_t peer_timeout_ms = 60000;
};

class ChatServer {
public:
    using Logger = std::function<void(const std::string&)>;

    explicit ChatServer(ServerConfig cfg);
    ~ChatServer();

    ChatServer(const ChatServer&) = delete;
    ChatServer& operator=(const ChatServer&) = delete;

    bool start();
    void stop();

    bool running() const { return running_.load(); }
    size_t online_count() const;
    void broadcast_notice(const std::string& text);
    void set_logger(Logger logger);

private:
    struct Peer {
        std::string name;
        sockaddr_in addr{};
        int64_t last_seen = 0;
    };

    struct Message {
        std::string id;
        std::string from;
        std::string text;
        std::string to;
        int64_t ts = 0;
        bool history = false;
    };

    void udp_loop();
    void handle_packet_locked(const std::string& raw, const sockaddr_in& from);
    void broadcast_locked(const std::string& data, const std::string& skip_name = "");
    bool send_to_name_locked(const std::string& name, const std::string& data);
    void send_udp(const sockaddr_in& addr, const std::string& data);
    void push_history_locked(const Message& m);
    void broadcast_users_locked();
    std::vector<std::string> online_names_locked() const;
    std::string unique_name_locked(const std::string& base, const std::string& self);
    std::string welcome_json_locked(const std::string& name);
    std::string next_id_locked();
    std::string sanitize_name(const std::string& raw);
    void gc_peers();
    void log(const std::string& tag, const std::string& text);

    ServerConfig cfg_;
    socket_t sock_ = kInvalidSocket;
    std::atomic<bool> running_{false};
    std::thread thread_;

    mutable std::recursive_mutex mtx_;
    std::map<std::string, Peer> peers_;
    std::deque<Message> history_;
    uint64_t counter_ = 0;

    Logger logger_;
    mutable std::mutex logger_mtx_;
};

}  // namespace chat
