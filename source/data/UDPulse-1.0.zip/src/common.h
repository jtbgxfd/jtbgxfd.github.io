#pragma once
// ============================================================================
//  UDPulse · 公共工具（纯 C++，无第三方依赖）
//  - 跨平台 Socket 封装（WinSock2 / BSD Socket）
//  - UTF-8 / UTF-16 转换、时间、日志
//  - 单层 JSON 编解码（聊天协议都是扁平对象）
// ============================================================================

#ifdef _WIN32
#  ifndef WIN32_LEAN_AND_MEAN
#    define WIN32_LEAN_AND_MEAN
#  endif
#  ifndef NOMINMAX
#    define NOMINMAX
#  endif
#  include <winsock2.h>
#  include <ws2tcpip.h>
#  include <windows.h>
#  include <shellapi.h>
#else
#  include <arpa/inet.h>
#  include <fcntl.h>
#  include <netinet/in.h>
#  include <netinet/tcp.h>
#  include <signal.h>
#  include <sys/socket.h>
#  include <sys/types.h>
#  include <unistd.h>
#endif

#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iostream>
#include <map>
#include <mutex>
#include <string>
#include <vector>

namespace chat {

// ---------------------------------------------------------------- socket 类型
#ifdef _WIN32
using socket_t = SOCKET;
using sock_len_t = int;
static const socket_t kInvalidSocket = INVALID_SOCKET;
#else
using socket_t = int;
using sock_len_t = socklen_t;
static const socket_t kInvalidSocket = -1;
#endif

// ------------------------------------------------------------ WinSock 生命周期
struct SocketRuntime {
    SocketRuntime() {
#ifdef _WIN32
        WSADATA data;
        WSAStartup(MAKEWORD(2, 2), &data);
#endif
    }
    ~SocketRuntime() {
#ifdef _WIN32
        WSACleanup();
#endif
    }
    SocketRuntime(const SocketRuntime&) = delete;
    SocketRuntime& operator=(const SocketRuntime&) = delete;
};

inline void socket_close(socket_t s) {
    if (s == kInvalidSocket) return;
#ifdef _WIN32
    closesocket(s);
#else
    ::close(s);
#endif
}

inline bool socket_valid(socket_t s) { return s != kInvalidSocket; }

inline bool set_reuseaddr(socket_t s) {
    int yes = 1;
    return setsockopt(s, SOL_SOCKET, SO_REUSEADDR,
                      reinterpret_cast<const char*>(&yes), sizeof(yes)) == 0;
}

inline bool would_block() {
#ifdef _WIN32
    const int err = WSAGetLastError();
    return err == WSAEWOULDBLOCK || err == WSAEINPROGRESS;
#else
    return errno == EAGAIN || errno == EWOULDBLOCK || errno == EINPROGRESS;
#endif
}

inline bool last_socket_error_ignorable() {
#ifdef _WIN32
    const int err = WSAGetLastError();
    return err == WSAEWOULDBLOCK || err == WSAEINTR || err == WSAETIMEDOUT;
#else
    return errno == EAGAIN || errno == EWOULDBLOCK || errno == EINTR;
#endif
}

// 设置接收超时，便于线程循环检查退出标志
inline void set_recv_timeout(socket_t s, int ms) {
#ifdef _WIN32
    DWORD timeout = static_cast<DWORD>(ms);
    setsockopt(s, SOL_SOCKET, SO_RCVTIMEO, reinterpret_cast<const char*>(&timeout), sizeof(timeout));
#else
    timeval tv{ms / 1000, (ms % 1000) * 1000};
    setsockopt(s, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
#endif
}

// ---------------------------------------------------------------- 控制台 UTF-8
inline void setup_console() {
#ifdef _WIN32
    SetConsoleOutputCP(CP_UTF8);
    SetConsoleCP(CP_UTF8);
#endif
}

// --------------------------------------------------------------- 编码转换
#ifdef _WIN32
inline std::string wide_to_utf8(const std::wstring& wide) {
    if (wide.empty()) return std::string();
    const int len = WideCharToMultiByte(CP_UTF8, 0, wide.c_str(),
                                        static_cast<int>(wide.size()), nullptr, 0, nullptr, nullptr);
    if (len <= 0) return std::string();
    std::string out(static_cast<size_t>(len), '\0');
    WideCharToMultiByte(CP_UTF8, 0, wide.c_str(), static_cast<int>(wide.size()),
                        &out[0], len, nullptr, nullptr);
    return out;
}

inline std::wstring utf8_to_wide(const std::string& utf8) {
    if (utf8.empty()) return std::wstring();
    const int len = MultiByteToWideChar(CP_UTF8, 0, utf8.c_str(),
                                        static_cast<int>(utf8.size()), nullptr, 0);
    if (len <= 0) return std::wstring();
    std::wstring out(static_cast<size_t>(len), L'\0');
    MultiByteToWideChar(CP_UTF8, 0, utf8.c_str(), static_cast<int>(utf8.size()),
                        &out[0], len);
    return out;
}

// Windows 下 main 的 argv 按 ANSI 代码页转换，中文会乱码；从 UTF-16 命令行重新解析
inline std::vector<std::string> utf8_command_line_args() {
    int argc = 0;
    LPWSTR* wargv = CommandLineToArgvW(GetCommandLineW(), &argc);
    std::vector<std::string> args;
    if (!wargv) return args;
    args.reserve(static_cast<size_t>(argc));
    for (int i = 0; i < argc; ++i) args.push_back(wide_to_utf8(wargv[i]));
    LocalFree(wargv);
    return args;
}
#endif

// ------------------------------------------------------------------ 时间
inline int64_t now_ms() {
    using namespace std::chrono;
    return duration_cast<milliseconds>(system_clock::now().time_since_epoch()).count();
}

inline std::string format_clock(int64_t ms) {
    const std::time_t secs = static_cast<std::time_t>(ms / 1000);
    std::tm tmv{};
#ifdef _WIN32
    localtime_s(&tmv, &secs);
#else
    localtime_r(&secs, &tmv);
#endif
    char buf[16];
    std::snprintf(buf, sizeof(buf), "%02d:%02d:%02d", tmv.tm_hour, tmv.tm_min, tmv.tm_sec);
    return std::string(buf);
}

// ------------------------------------------------------------------ 日志
inline std::mutex& log_mutex() {
    static std::mutex m;
    return m;
}

inline void log_line(const std::string& tag, const std::string& text) {
    std::lock_guard<std::mutex> lock(log_mutex());
    std::cout << "[" << format_clock(now_ms()) << "] " << tag << " " << text << std::endl;
}

// --------------------------------------------------------------- UTF-8 工具
inline void append_utf8(std::string& out, uint32_t cp) {
    if (cp <= 0x7F) {
        out.push_back(static_cast<char>(cp));
    } else if (cp <= 0x7FF) {
        out.push_back(static_cast<char>(0xC0 | (cp >> 6)));
        out.push_back(static_cast<char>(0x80 | (cp & 0x3F)));
    } else if (cp <= 0xFFFF) {
        out.push_back(static_cast<char>(0xE0 | (cp >> 12)));
        out.push_back(static_cast<char>(0x80 | ((cp >> 6) & 0x3F)));
        out.push_back(static_cast<char>(0x80 | (cp & 0x3F)));
    } else {
        out.push_back(static_cast<char>(0xF0 | (cp >> 18)));
        out.push_back(static_cast<char>(0x80 | ((cp >> 12) & 0x3F)));
        out.push_back(static_cast<char>(0x80 | ((cp >> 6) & 0x3F)));
        out.push_back(static_cast<char>(0x80 | (cp & 0x3F)));
    }
}

inline std::string utf8_truncate(const std::string& s, size_t max_chars) {
    size_t i = 0, count = 0;
    while (i < s.size() && count < max_chars) {
        const unsigned char c = static_cast<unsigned char>(s[i]);
        size_t len = 1;
        if ((c & 0x80) == 0x00) len = 1;
        else if ((c & 0xE0) == 0xC0) len = 2;
        else if ((c & 0xF0) == 0xE0) len = 3;
        else if ((c & 0xF8) == 0xF0) len = 4;
        if (i + len > s.size()) break;
        i += len;
        ++count;
    }
    return s.substr(0, i);
}

inline size_t utf8_length(const std::string& s) {
    size_t count = 0;
    for (size_t i = 0; i < s.size();) {
        const unsigned char c = static_cast<unsigned char>(s[i]);
        size_t len = 1;
        if ((c & 0x80) == 0x00) len = 1;
        else if ((c & 0xE0) == 0xC0) len = 2;
        else if ((c & 0xF0) == 0xE0) len = 3;
        else if ((c & 0xF8) == 0xF0) len = 4;
        i += len;
        ++count;
    }
    return count;
}

// ---------------------------------------------------------------- JSON 工具
inline std::string json_escape(const std::string& s) {
    std::string out;
    out.reserve(s.size() + 8);
    for (unsigned char c : s) {
        switch (c) {
            case '"': out += "\\\""; break;
            case '\\': out += "\\\\"; break;
            case '\n': out += "\\n"; break;
            case '\r': out += "\\r"; break;
            case '\t': out += "\\t"; break;
            case '\b': out += "\\b"; break;
            case '\f': out += "\\f"; break;
            default:
                if (c < 0x20) {
                    char buf[8];
                    std::snprintf(buf, sizeof(buf), "\\u%04x", c);
                    out += buf;
                } else {
                    out.push_back(static_cast<char>(c));
                }
        }
    }
    return out;
}

// 解析单层 JSON 对象：{"type":"msg","ts":123,"history":true}
inline std::map<std::string, std::string> parse_json_object(const std::string& src) {
    std::map<std::string, std::string> result;
    size_t i = 0;
    const size_t n = src.size();

    auto skip_ws = [&]() {
        while (i < n && (src[i] == ' ' || src[i] == '\t' || src[i] == '\n' || src[i] == '\r')) ++i;
    };

    auto read_string = [&](std::string& out) -> bool {
        if (i >= n || src[i] != '"') return false;
        ++i;
        out.clear();
        while (i < n) {
            const char c = src[i++];
            if (c == '"') return true;
            if (c != '\\') {
                out.push_back(c);
                continue;
            }
            if (i >= n) return false;
            const char esc = src[i++];
            switch (esc) {
                case '"': out.push_back('"'); break;
                case '\\': out.push_back('\\'); break;
                case '/': out.push_back('/'); break;
                case 'b': out.push_back('\b'); break;
                case 'f': out.push_back('\f'); break;
                case 'n': out.push_back('\n'); break;
                case 'r': out.push_back('\r'); break;
                case 't': out.push_back('\t'); break;
                case 'u': {
                    if (i + 4 > n) return false;
                    uint32_t cp = 0;
                    for (int k = 0; k < 4; ++k) {
                        const char h = src[i + k];
                        cp <<= 4;
                        if (h >= '0' && h <= '9') cp |= static_cast<uint32_t>(h - '0');
                        else if (h >= 'a' && h <= 'f') cp |= static_cast<uint32_t>(h - 'a' + 10);
                        else if (h >= 'A' && h <= 'F') cp |= static_cast<uint32_t>(h - 'A' + 10);
                        else return false;
                    }
                    i += 4;
                    if (cp >= 0xD800 && cp <= 0xDBFF && i + 6 <= n && src[i] == '\\' && src[i + 1] == 'u') {
                        uint32_t low = 0;
                        bool ok = true;
                        for (int k = 0; k < 4; ++k) {
                            const char h = src[i + 2 + k];
                            low <<= 4;
                            if (h >= '0' && h <= '9') low |= static_cast<uint32_t>(h - '0');
                            else if (h >= 'a' && h <= 'f') low |= static_cast<uint32_t>(h - 'a' + 10);
                            else if (h >= 'A' && h <= 'F') low |= static_cast<uint32_t>(h - 'A' + 10);
                            else { ok = false; break; }
                        }
                        if (ok && low >= 0xDC00 && low <= 0xDFFF) {
                            cp = 0x10000 + ((cp - 0xD800) << 10) + (low - 0xDC00);
                            i += 6;
                        }
                    }
                    append_utf8(out, cp);
                    break;
                }
                default: out.push_back(esc); break;
            }
        }
        return false;
    };

    skip_ws();
    if (i >= n || src[i] != '{') return result;
    ++i;
    while (i < n) {
        skip_ws();
        if (i < n && src[i] == '}') break;
        if (i >= n || src[i] != '"') break;
        std::string key;
        if (!read_string(key)) break;
        skip_ws();
        if (i >= n || src[i] != ':') break;
        ++i;
        skip_ws();
        if (i >= n) break;

        if (src[i] == '"') {
            std::string value;
            if (!read_string(value)) break;
            result[key] = value;
        } else if (src[i] == '{' || src[i] == '[') {
            int depth = 0;
            bool in_str = false;
            while (i < n) {
                const char c = src[i];
                if (in_str) {
                    if (c == '\\') { i += 2; continue; }
                    if (c == '"') in_str = false;
                } else {
                    if (c == '"') in_str = true;
                    else if (c == '{' || c == '[') ++depth;
                    else if (c == '}' || c == ']') {
                        --depth;
                        if (depth == 0) { ++i; break; }
                    }
                }
                ++i;
            }
        } else {
            const size_t start = i;
            while (i < n && src[i] != ',' && src[i] != '}' && src[i] != ' ') ++i;
            result[key] = src.substr(start, i - start);
        }

        skip_ws();
        if (i < n && src[i] == ',') { ++i; continue; }
        if (i < n && src[i] == '}') break;
    }
    return result;
}

inline std::string json_get(const std::map<std::string, std::string>& obj,
                            const std::string& key,
                            const std::string& fallback = "") {
    auto it = obj.find(key);
    return it == obj.end() ? fallback : it->second;
}

inline int64_t json_get_int(const std::map<std::string, std::string>& obj,
                            const std::string& key,
                            int64_t fallback = 0) {
    auto it = obj.find(key);
    if (it == obj.end() || it->second.empty()) return fallback;
    try {
        return std::stoll(it->second);
    } catch (...) {
        return fallback;
    }
}

}  // namespace chat
