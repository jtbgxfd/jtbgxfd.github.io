#pragma once
// ============================================================================
//  ChatClient · 纯 UDP 客户端
//  接收线程把原始 JSON 交给回调，由 UI 层决定如何投递到界面线程
// ============================================================================
#include "common.h"

#include <atomic>
#include <functional>
#include <mutex>
#include <string>
#include <thread>

namespace chat {

class ChatClient {
public:
    using Handler = std::function<void(const std::string& raw_json)>;

    ChatClient() = default;
    ~ChatClient();

    ChatClient(const ChatClient&) = delete;
    ChatClient& operator=(const ChatClient&) = delete;

    bool connect_to(const std::string& host, uint16_t port);
    void set_handler(Handler handler);
    void send_json(const std::string& payload);
    void close();

    bool connected() const { return connected_.load(); }
    const std::string& server_host() const { return server_host_; }
    uint16_t server_port() const { return server_port_; }

private:
    void recv_loop();

    socket_t sock_ = kInvalidSocket;
    sockaddr_in server_{};
    std::thread thread_;
    std::atomic<bool> running_{false};
    std::atomic<bool> connected_{false};
    Handler handler_;
    std::mutex handler_mtx_;
    std::string server_host_;
    uint16_t server_port_ = 0;
};

}  // namespace chat
