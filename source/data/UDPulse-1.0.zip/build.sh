#!/usr/bin/env bash
# 构建脚本（MSYS2 / MinGW-w64 环境）
set -e
cd "$(dirname "$0")"

CXX="${CXX:-g++}"

echo "正在编译 UDPulse.exe ..."
$CXX -std=c++17 -O2 -DUNICODE -D_UNICODE -mwindows -pthread \
    src/main.cpp src/ui.cpp src/chat_server.cpp src/chat_client.cpp \
    -o UDPulse.exe \
    -lgdiplus -lws2_32 -limm32 -lgdi32 -luser32 -lshell32 \
    -static -static-libgcc -static-libstdc++

echo "构建完成：UDPulse.exe"
ls -lh UDPulse.exe
