#undef JTBG_ALL
#define JTBG_ALL
#include "jtbg.h"
#include <iostream>
#define KX_D "V1.0.7"
#include <thread>
using namespace std;
string mip, dip, lip;
uint16_t mport, dport, lport;
UDPSocket socketssss;
bool dev = 0;
int fsend(string a, string b, uint16_t c)
{
	return socketssss.send(a, b, c);
}
int ssend(string a, string b, uint16_t c)
{
	a = xorpass(a, "[JTBG FAST KUAIXIN]");
	return socketssss.send(a, b, c);
}
string sread(string a)
{
	a = xorpass(a, "[JTBG FAST KUAIXIN]");
	return a;
}
int main()
{
	string tmp;
	system("title JTBG����-���ٰ�");
	Sleep(1000);
	system("cls");
	cout << "��ӭʹ��JTBG����-���ٰ� " << KX_D << endl;
	cout << "����IP(ͨ��cmd��ipconfig�鿴):";
	cin >> mip;
	cout << "������һ���˿�(1000-19999):";
	cin >> mport;
	if (mport > 19999 || mport < 1000) mport = 12508;
	cout << "�Է���IP(ͨ��cmd��ipconfig�鿴):";
	cin >> dip;
	cout << "�Է��Ķ˿�(1000-19999):";
	cin >> dport;
	if (dport > 19999 || dport < 1000) dport = 12508;
	getline(cin, tmp);
	cout << "����������IP(�س�Ϊ��):";
	getline(cin, lip);
	if (lip == "")
	{
		lport = 999;
	}
	else
	{
		lport = 8888;
	}
gol:
	if (!socketssss.bind(mport))
	{
		cout << "��ʧ��" << endl;
		mport = rd(10000, 19999);
		if (dev) cout << "RESET IN [" << mport << "]" << endl;
		goto gol;
	}
stl:
	Sleep(2000);
	system("cls");
	cout << "��������-���ٰ�����" << endl;
	cout << "����: " << mip << ":" << mport << endl;
	cout << "�Է�: " << dip << ":" << dport << endl;
	socketssss.start_recv(
	    [](const string & data, const string & from_ip, uint16_t from_port)
	{
		string plain = sread(data);          // ���±�������
		cout << "\n[" << from_ip << ":" << from_port << "]: " << plain << endl;
		cout << "> ";
		cout.flush();
		stringstream lis;
		lis << "[" << from_ip << ":" << from_port << "]: " << plain;
		fsend(lis.str(), lip, lport);
	}
	);
	string lls;
	lls = "�Է�������" ;
	ssend(lls, dip, dport);
	while (1)
	{
		cout << "> ";
		string message;
		getline(cin, message);
		if (message.empty()) continue;
		int sent = ssend(message, dip, dport);
		if (dev)
		{
			cout << "send(" << message << "," << dip << "," << dport << ")" << endl;
		}
		stringstream lis;
		lis << "[" << mip << ":" << mport << "]: " << message;
		fsend(lis.str(), lip, lport);
		if (dev)
		{
			cout << "send(" << lis.str() << "," << lip << "," << lport << ")" << endl;
		}
		if (sent <= 0)
		{
			cout << "[error] ����ʧ��!" << endl;
			cout << "��������..." << endl;
			for (int i = 0; i < 3; i++)
			{
				if (dev) cout << "RETRY IN " << i + 1 << endl;
				sent = ssend(message, dip, dport);
				if (sent > 0)
				{
					cout << "���ͳɹ�!" << endl;
					break;
				}
				else
				{
					cout << "[error] ����ʧ��!" << endl;
				}
			}
		}
	}
	socketssss.stop_recv();
	socketssss.close();
	return 0;
}
